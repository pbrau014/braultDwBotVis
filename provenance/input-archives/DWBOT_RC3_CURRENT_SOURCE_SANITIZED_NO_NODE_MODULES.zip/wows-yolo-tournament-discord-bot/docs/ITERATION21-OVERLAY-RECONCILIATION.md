# Iteration 21 overlay reconciliation — 2026-10-28

## Status

The overlay was applied only to a separate working copy extracted from the SHA-256-verified V4 archive. The original source archive, patch archive, duplicate patch archive, and existing GitHub repository were not modified by this local reconciliation.

## Non-negotiable acceptance invariant

All nine fields are required in this exact order: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `freeXp`, `damage`, `xp`. XP is mandatory and ninth/final. Missing, invalid, uncertain, conflicting, or incorrect values must block acceptance.

## Overlay integrity

- V4 archive SHA-256: `b57942298f9d1405946f2eadf249ece94cf1cde05131172e44d0a4cd51099899`
- Iteration 21 patch SHA-256: `35bdedfcfdeb3f861bb6b8e444732962644a053b7140c7494504a13e6c858d14`
- Duplicate patch archive SHA-256: identical to Iteration 21 patch.
- Patch manifest: 21/21 listed entries verified against their SHA-256 values.
- All three ZIP archives passed ZIP integrity checks.

## Reconciliation changes

The overlay's original optional-XP behavior was adapted to the required nine-field contract across the battle-record validator, bot validation checks and status text, exact-match acceptance helpers, OCR sequence/regression/metrics scripts, active screenshot manifests, one-value-at-a-time correction flow, regression tests, README, and `plan1.txt`. Acceptance now fails closed for legacy reports that lack the explicit all-nine-field result. Historical reports and prior metrics remain historical and were not relabeled as current-contract results.

## Test evidence

- `npm test`: 178 passed, 0 failed, 0 skipped, Linux x64 Node `v24.17.0`, npm `11.13.0`. The same suite also passed under Node `v22.16.0`.
- The JavaScript syntax sweep passed for every `.js` file under `src/`, `scripts/`, and `tests/`; local Tesseract.js asset validation passed under Node `v24.17.0`.
- This test pass is not a Windows Node 24 OCR acceptance pass. `npm ci --no-audit --no-fund` did not complete within the available execution window; no clean-install pass is claimed and archive-provided `node_modules` was restored. A real one-image OCR sequence also exceeded the execution window and produced no report; it was terminated and is not counted as a pass. Target-Windows OCR acceptance, independent holdout validation, Discord staging, backup/restore, and release gates remain open.

## Release decision

**Production NO-GO.** Do not migrate or deploy until the clean supported-runtime install, current-source OCR acceptance, independent holdout, and authorized staging/restore gates pass.
