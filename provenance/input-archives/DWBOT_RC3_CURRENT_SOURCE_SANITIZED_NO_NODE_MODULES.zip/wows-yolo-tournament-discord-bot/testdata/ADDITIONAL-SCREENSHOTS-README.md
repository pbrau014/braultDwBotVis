# Additional screenshot regression corpus

This corpus contains all 16 images supplied in `imgs2add.zip`. The original filenames are preserved under `fixtures/additional-screenshots/`. SHA-256 values and field-by-field annotations are stored in `additional-screenshot-ground-truth.json`.

Run `npm run test:additional-images` to exercise all 16 images sequentially through the production OCR extraction and supervised child-process path, using local Tesseract.js assets with the network guard enabled. The test requires all nine mandatory fields to match exactly on every image, including XP as the ninth/final field, all required fields to be present, all children to close successfully, and no network attempt to be recorded.

The existing five approved acceptance fixtures and their expected values were not modified. The manifest lists all nine contract fields in `requiredComparedFields` and `comparedFields`; `optionalComparedFields` is empty. These 16 annotations were transcribed from the screenshots supplied with this change; do not change an expected value merely to obtain a passing run. If an annotation is suspected to be wrong, review the original screenshot and record an explicit correction rationale before modifying it.
