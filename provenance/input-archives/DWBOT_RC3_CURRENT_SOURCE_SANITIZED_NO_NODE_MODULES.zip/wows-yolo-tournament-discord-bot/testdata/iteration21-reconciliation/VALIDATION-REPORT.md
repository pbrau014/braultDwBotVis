# Iteration 21 reconciliation validation report — 2026-10-28

## Inputs

- V4 source archive SHA-256: `b57942298f9d1405946f2eadf249ece94cf1cde05131172e44d0a4cd51099899` — verified.
- Iteration 21 patch SHA-256: `35bdedfcfdeb3f861bb6b8e444732962644a053b7140c7494504a13e6c858d14` — verified.
- Duplicate patch `(2)` has the same SHA-256 as `(1)` and is byte-identical.
- All three input ZIP archives passed `ZipFile.testzip()` integrity checks.
- Iteration 21 SHA256 manifest: 21/21 entries matched.

## Contract reconciliation

The patch was applied to a separate working copy, then adapted to require all nine fields in exact order: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `freeXp`, `damage`, `xp`. XP is mandatory and ninth/final. The active validator, one-value correction flow, acceptance helpers, comparison/metrics scripts, active manifests, regression corpus contract, README, and `plan1.txt` were updated. Acceptance fails closed if a report does not provide explicit nine-field acceptance. Historical evidence was preserved as historical and not relabeled.

## Verification

| Check | Result | Notes |
|---|---|---|
| `npm test` | PASS | 178 passed, 0 failed, 0 skipped, Linux x64 Node v24.17.0 |
| JavaScript syntax sweep | PASS | `node --check` for all `.js` files under `src/`, `scripts/`, and `tests/` |
| `node scripts/check-tesseractjs-assets.js` | PASS | Tesseract.js 6.0.1 / core 6.1.2; all listed local assets present |
| `npm ci --no-audit --no-fund` | NOT VERIFIED | Did not complete within the available execution window; no clean-install pass claimed |
| Real OCR sequence (`asashio-defeat.jpg`) | NOT VERIFIED | Exceeded execution window; child chain terminated; no report produced |
| Target Windows Node 24 OCR acceptance | OPEN | Not run in this Linux environment |
| Independent untouched holdout | OPEN | Must use new, double-labeled screenshots |
| Live Discord staging / restore / rollback | OPEN | Not run |

## Release decision

**Production NO-GO.** The local contract/unit regression suite passes, but this is not release approval. Complete a clean supported-runtime install, the full current-source OCR acceptance sequence on target Windows Node 24, independent holdout validation, and authorized Discord staging/backup/restore/rollback before release or repository migration.
