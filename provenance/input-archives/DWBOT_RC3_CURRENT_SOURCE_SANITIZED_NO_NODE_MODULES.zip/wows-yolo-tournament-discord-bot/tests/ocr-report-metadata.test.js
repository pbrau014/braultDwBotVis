'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { createOcrReportMetadata } = require('../src/ocr-report-metadata');

test('OCR reports include reproducible build, engine, language-model and local asset identity', () => {
    const metadata = createOcrReportMetadata(path.join(__dirname, '..'));
    assert.equal(metadata.package.version, require('../package.json').version);
    assert.match(metadata.sourceBuild.sha256, /^[a-f0-9]{64}$/);
    assert.ok(metadata.sourceBuild.files > 0);
    assert.equal(metadata.engineVersions.tesseractJs, require('tesseract.js/package.json').version);
    assert.equal(metadata.engineVersions.tesseractJsCore, require('tesseract.js-core/package.json').version);
    assert.equal(metadata.languageModel.language, 'eng');
    assert.match(metadata.languageModel.sha256, /^[a-f0-9]{64}$/);
    assert.ok(metadata.localAssets.length >= 2);
    assert.ok(metadata.localAssets.every(asset => asset.exists && /^[a-f0-9]{64}$/.test(asset.sha256)));
});
