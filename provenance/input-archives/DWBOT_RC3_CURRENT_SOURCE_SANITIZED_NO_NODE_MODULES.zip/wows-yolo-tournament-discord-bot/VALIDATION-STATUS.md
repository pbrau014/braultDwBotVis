# Validation status — WoWS OCR + YOLO Tournament Discord Bot 2.5.0

Updated: 2026-10-24, after Phase 0 baseline reconciliation.

## Current verified state

| Area | Current status | Evidence and limits |
|---|---|---|
| Windows clean install | **Verified in user-provided PowerShell output** | Node.js v24.22.1 and npm 11.19.1. `npm ci` added 39 packages and audited 40; npm reported 0 vulnerabilities. `npm ls --depth=0` listed discord.js 14.27.0, dotenv 16.6.1, tesseract.js 6.0.1, and tesseract.js-core 6.1.2. |
| Windows baseline test before Phase 0 correction | **One test failure found** | The supplied run reported 74 tests: 71 passed, 1 failed, 2 skipped. The failure was the interactive panel test at `tests/full-system.test.js:817`; two POSIX-specific process-cancellation fixtures were skipped on Windows. |
| Interactive-panel test correction | **Implemented and verified in this environment** | The test now inspects actual serialized discord.js builder payloads using `toJSON()` and verifies both option values and labels. The focused system file passed 5/5; the full suite passed 74/74, 0 failed, 0 skipped on this Linux environment with the actual dependency packages from the ZIP. Runtime here is Node.js v22.16.0 and npm 10.9.2, below the package's declared runtime; rerun `npm test` on Windows Node.js 24.22.1 after extracting the new ZIP. |
| Test-report overwrite protection | **Implemented** | `scripts/run-reported-screenshot-regression.js` now supports `REPORTED_SCREENSHOT_REPORT_PATH` so a new engine run can save to a separate file instead of overwriting the default tracked baseline report. Verified by a fresh fallback report written to `testdata/phase0-baseline/`. |
| Tesseract.js local asset startup | **Runtime initialization observed** | The real Tesseract.js 6.0.1 package starts and performs OCR using its local language/worker/core configuration in this environment. This does not imply accuracy or production readiness. |
| Tesseract.js reported screenshot exact-match | **Fail** | Fresh report: 8/9 expected fields match; damage is `87313` instead of `87373`; no required fields are missing. Therefore the current fallback can mark a wrong value as complete. See `testdata/phase0-baseline/tesseractjs-reported-screenshot-baseline.json`. |
| Tesseract.js four-image baseline | **Fail exact-match; all jobs complete** | Fresh sequential report: 4/4 jobs completed; 0/4 all-expected-fields matches; required fields complete for 1/4. Per-image time was approximately 28.4–37.0 seconds. See `testdata/phase0-baseline/tesseractjs-four-image-baseline.json`. This one run does not disprove the historical intermittent stall; repeated sequential and injected-timeout tests remain necessary. |
| Native Tesseract CLI in this environment | **Direct CLI check passed; full bot pipeline inconclusive** | `/usr/bin/tesseract` version 5.5.0 is present here. A direct `tesseract <fixture> stdout --psm 3` run reads damage as `87373`. The full bot native reported-screenshot command did not finish within this environment's 120-second execution window and wrote no report; it is not counted as a pass. |
| Native Tesseract CLI on the user's Windows machine | **Unavailable through PATH** | User's `Get-Command tesseract`, `tesseract --version`, and `tesseract --list-langs` failed. Install or locate the CLI on Windows for direct native comparisons; JavaScript fallback testing can proceed independently. |
| ZIP packaging | **Packaging issue found and corrected in Phase 0 candidate** | Input ZIP contained `node_modules` (3,298 extra file entries beyond the 58-file source manifest) despite `.gitignore` excluding it. The Phase 0 candidate omits `node_modules`, `.env`, and live `data/`; it retains `package.json` and `package-lock.json` for `npm ci`. |
| Workbook formula baseline | **Verified by static OOXML inspection and tests** | Workbook SHA-256 `12ad80209ef77451b3586b52359a06b5361a68bc9926fc81a9da3d6c4b586397`. `Totals!G12 = SUM(G3:G11,G14:G54)` cached at `2312.5598233298197`; `Totals!H12 = 0.54*G12/100` cached at `12.487823045981026` (display `$12.49`). Grand Yolo default tier weight remains 0.9. |
| Live Discord auth, permissions, uploads, rate limits | **Not tested** | Requires authorized access to the actual configured Discord bot/server. No live login or channel settings were changed. |

## Phase 0 changes

- Corrected the panel integration test to check `StringSelectMenuBuilder.toJSON()` rather than assuming `builder.data.options` exists. The production panel behavior was not changed; the test now validates the serialized Discord API component format and checks event labels as well as values.
- Added `REPORTED_SCREENSHOT_REPORT_PATH` support in the reported-screenshot runner so future OCR experiments can preserve historical baseline results.
- Created a baseline report and preserved fresh fallback results under `testdata/phase0-baseline/`.
- Rebuilt the Phase 0 candidate without bundled `node_modules`; dependency installation is performed with the lockfile instead.

## Remaining work for subsequent phases

1. Rerun `npm ci`, `npm ls --depth=0`, and `npm test` in the user's Windows Node.js 24.22.1 environment using the Phase 0 candidate. Confirm the panel test now passes and investigate Windows process-cancellation coverage for the two previously skipped tests.
2. Diagnose and fix the fallback's exact-match failures. The current uploaded build does not contain the later-reported damage consensus fix: the fresh reported screenshot still reads damage 87313 rather than 87373.
3. Add/run the cross-platform `npm run test:tesseractjs` acceptance launcher, with local-only/no-network asset verification and separate reports.
4. Prove sequential five-image processing with repeated runs, both two-image orders, injected stalls, confirmed process/worker termination, promise settlement and queue recovery.
5. Install or locate native Tesseract CLI on Windows and compare it fairly against Tesseract.js using documented versions and settings. Direct CLI success here does not substitute for a full native pipeline result.
6. Implement and test the optional local diagnostic/verified-correction feedback system. Do not treat unreviewed OCR output as ground truth.
7. Complete the existing-public-channel Discord smoke test and preserve the workbook `$12.49` regression.

## Release recommendation

**Phase 0 baseline reconciliation is complete, but the Tesseract.js fallback is not production-ready.** It starts and completes all four baseline jobs, but exact-field accuracy is 0/4 and the reported screenshot's damage remains incorrect. The new Phase 0 package fixes the baseline test harness and packaging issues; it does not claim to fix the OCR mismatches or the historical timeout concern.
