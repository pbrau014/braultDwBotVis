'use strict';

// Executes the production extractText -> validation -> battle-record path on
// the four user-provided screenshots in ../fixtures/four-screenshots.
// Discord is stubbed only to prevent a real client/login in this offline test.
const Module = require('node:module');
const path = require('node:path');
const fs = require('node:fs/promises');
const originalLoad = Module._load;
Module._load = function patchedLoad(request, parent, isMain) {
    if (request === 'dotenv') return { config() {} };
    if (request === 'discord.js') {
        class MockClient {
            on() { return this; }
            once() { return this; }
            destroy() {}
            async login() {}
        }
        return {
            Client: MockClient,
            GatewayIntentBits: { Guilds: 1, GuildMessages: 2, MessageContent: 4 },
            Events: { MessageCreate: 'messageCreate', ClientReady: 'ready' },
            Partials: { Channel: 1 },
        };
    }
    return originalLoad.call(this, request, parent, isMain);
};

const bot = require('../src/bot');
const { compareExpected } = require('../src/acceptance-checks');
const { nativeTesseractAvailable } = require('../src/ocr-worker');
const packageInfo = require('../package.json');
const fixtureDir = path.join(__dirname, '..', 'fixtures', 'four-screenshots');
const outputPath = process.env.FOUR_SCREENSHOT_REPORT_PATH || path.join(__dirname, '..', 'testdata', 'four-screenshot-pipeline-results.json');
const expected = {
    'hoffmann-victory.png': { result: 'Victory', player: '[-SEN-]WorldSpOwn', map: 'Mountain Range', mode: 'Random Battle', battleStart: '27.03.2025 23:55', credits: 1237152, xp: 14390, freeXp: 1645, damage: 303622 },
    'asashio-defeat.jpg': { result: 'Defeat', player: '[OVF]OldschoolGaming_YouTube', map: 'Northern Lights', mode: 'Random Battle', battleStart: '14.07.2024 22:51', credits: 1650259, xp: 4059, freeXp: 2110, damage: 171577 },
    'libertad-victory.jpg': { result: 'Victory', player: '[OVF]OldschoolGaming_YouTube', map: 'Sea of Fortune', mode: 'Random Battle', battleStart: '27.12.2024 23:30', credits: 511113, xp: 4509, freeXp: 608, damage: 227678 },
    'schlieffen-defeat.jpg': { result: 'Defeat', player: '[ARGSY]Ensign_Cthulhu', map: 'Crash Zone Alpha', mode: 'Brawl', battleStart: '28.08.2025 20:06', credits: 317943, xp: 2653, freeXp: 325, damage: 131828 },
};

(async () => {
    const results = [];
    const requested = new Set(process.argv.slice(2));
    const entries = Object.entries(expected).filter(([filename]) => requested.size === 0 || requested.has(filename));
    if (requested.size && entries.length !== requested.size) {
        throw new Error(`Unknown screenshot argument. Choose: ${Object.keys(expected).join(', ')}`);
    }
    try {
        for (const [filename, groundTruth] of entries) {
            console.log(`\n[PIPELINE] ${filename}: OCR starts`);
            const startedAt = Date.now();
            try {
            const buffer = await fs.readFile(path.join(fixtureDir, filename));
            const output = await bot.extractText(buffer);
            const validations = output.attempts.map((attempt) => bot.validateWorldOfWarshipsScreenshot(attempt, output.fields));
            validations.sort((a, b) => a.missing.length - b.missing.length || b.confidence - a.confidence);
            const best = validations[0];
            const record = best.record;
            const actual = {
                result: record.result,
                player: record.player,
                ship: record.ship,
                map: record.map,
                mode: record.mode,
                battleStart: record.battleStart,
                credits: Number(record.credits) || null,
                xp: Number(record.xp) || null,
                freeXp: Number(record.freeXp) || null,
                damage: Number(record.damage) || null,
            };
            const compare = ['result', 'credits', 'freeXp', 'damage'];
            const { comparison, allMatch, requiredFieldsPass } = compareExpected(actual, groundTruth);
            const requiredMissing = bot.getMissingRequiredFields(record).map((field) => field.key || field.label);
            const row = {
                filename,
                elapsedMs: Date.now() - startedAt,
                pipelineCompleted: true,
                attempts: output.attempts.length,
                fields: actual,
                requiredMissing,
                comparison,
                numericAndResultPass: compare.every((key) => comparison[key].pass),
                allExpectedFieldsPass: allMatch,
                allRequiredFieldsPass: requiredFieldsPass,
            };
            results.push(row);
            console.log(JSON.stringify(row, null, 2));
            } catch (error) {
                const row = { filename, elapsedMs: Date.now() - startedAt, pipelineCompleted: false, error: error.message };
                results.push(row);
                console.error(JSON.stringify(row, null, 2));
            }
        }
    } finally {
        await bot.terminateOcrWorker().catch(() => {});
        Module._load = originalLoad;
    }
    const requestedEngine = String(process.env.OCR_ENGINE || 'auto').toLowerCase();
    const selectedEngine = requestedEngine === 'native'
        ? 'native Tesseract CLI + ImageMagick preprocessing'
        : requestedEngine === 'tesseractjs'
            ? 'Tesseract.js local assets + ImageMagick preprocessing'
            : nativeTesseractAvailable()
                ? 'native Tesseract CLI (auto-selected) + ImageMagick preprocessing'
                : 'Tesseract.js local assets (auto-selected) + ImageMagick preprocessing';
    const report = {
        buildVersion: packageInfo.version,
        createdAt: new Date().toISOString(),
        configuredEngine: requestedEngine,
        engine: selectedEngine,
        executionMode: entries.length === 1 ? 'single-fixture invocation' : 'all selected fixtures in one sequential invocation',
        source: 'the same four screenshots supplied in this conversation',
        imageCount: entries.length,
        completedImages: results.filter((row) => row.pipelineCompleted).length,
        numericAndResultMatched: results.filter((row) => row.numericAndResultPass).length,
        fullExpectedValuesMatched: results.filter((row) => row.allExpectedFieldsPass).length,
        mandatoryExactMatches: results.filter((row) => row.allRequiredFieldsPass).length,
        requiredFieldsComplete: results.filter((row) => Array.isArray(row.requiredMissing) && row.requiredMissing.length === 0).length,
        results,
    };
    await fs.writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`);
    console.log(`\n[PIPELINE] Report saved to ${outputPath}`);
    console.log(`[PIPELINE] images=${report.completedImages}/${entries.length}, mandatory exact=${report.mandatoryExactMatches}/${entries.length}, complete required fields=${report.requiredFieldsComplete}/${entries.length}, optional/all-field exact=${report.fullExpectedValuesMatched}/${entries.length}`);
    if (report.completedImages !== entries.length || report.mandatoryExactMatches !== entries.length || report.requiredFieldsComplete !== entries.length) process.exitCode = 1;
})().catch((error) => {
    console.error('[PIPELINE] Fatal error:', error);
    process.exitCode = 1;
});
