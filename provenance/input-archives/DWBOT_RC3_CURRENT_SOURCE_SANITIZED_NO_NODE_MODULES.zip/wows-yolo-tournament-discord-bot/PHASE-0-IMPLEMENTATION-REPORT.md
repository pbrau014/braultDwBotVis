# Phase 0 Implementation Report — v2.5.0 baseline reconciliation

Date: 2026-10-24
Application version remains: 2.5.0 (Phase 0 changes are test/diagnostic/packaging corrections, not a functional OCR release).

## Changes implemented

### 1. Fixed the failing panel integration test

File: `tests/full-system.test.js`

The prior test accessed `StringSelectMenuBuilder.data.options`, but with real discord.js 14.27.0 the option list is present in the serialized payload produced by `.toJSON()`. The production panel builder was valid; the test was coupled to an internal builder representation.

The test now serializes the buttons and select menu with `.toJSON()`, checks the custom IDs, checks all event values, and additionally checks the labels. This is an assertion/API-contract correction; the user-visible bot logic was not changed.

### 2. Added report output-path control

File: `scripts/run-reported-screenshot-regression.js`

The runner accepts `REPORTED_SCREENSHOT_REPORT_PATH`. This lets fallback/native runs write into a unique report file without overwriting the tracked historical baseline. The new override was used successfully for the fresh Tesseract.js baseline run.

### 3. Preserved the Phase 0 evidence

Files added:

- `PHASE-0-BASELINE-REPORT.md`
- `PHASE-0-IMPLEMENTATION-REPORT.md`
- `testdata/phase0-baseline/README.md`
- `testdata/phase0-baseline/tesseractjs-reported-screenshot-baseline.json`
- `testdata/phase0-baseline/tesseractjs-four-image-baseline.json`
- `testdata/phase0-baseline/native-tesseract-direct-psm3.txt`
- `testdata/phase0-baseline/native-tesseract-direct-psm3-stderr.txt`

The original tracked baseline report JSONs and synthetic example fixtures were preserved; test-generated temporary changes to the synthetic example exports were restored from the uploaded ZIP.

### 4. Corrected the release package assembly

The uploaded ZIP included thousands of `node_modules` files even though `.gitignore` excluded that directory. The Phase 0 candidate is repackaged without `node_modules`, `.env`, or live `data/`. It retains `package.json`, `package-lock.json`, the bundled OCR language model, workbook, source, fixtures, tests and reports. The Windows user has already shown that `npm ci` works against the v2.5.0 lockfile; a clean install against this newly packaged copy should still be confirmed.

## Verification performed

### Full system test file

Command:

`node --test tests/full-system.test.js`

Result: **5 passed, 0 failed, 0 skipped**. The public interactive panel test now verifies real discord.js builder serialization, option values and labels, totals/event selection behavior, and ignores interactions outside the configured channel.

### Full test suite

Command:

`npm test`

Result: **74 passed, 0 failed, 0 skipped** in this container, using the actual installed dependency packages included in the uploaded archive. Environment: Node.js v22.16.0, npm 10.9.2. Because the package requires Node.js >=24.17.0, this is a useful test/debug result but not a substitute for rerunning the new candidate on the user's Node.js 24.22.1 Windows environment.

### Syntax and dependency checks

- `node --check` passed for the changed test and reported-screenshot runner and relevant application files.
- `npm ls --depth=0` passed and listed discord.js 14.27.0, dotenv 16.6.1, tesseract.js 6.0.1 and tesseract.js-core 6.1.2.
- Package/lockfile root names, version 2.5.0 and Node engine declaration >=24.17.0 match.

### Fresh Tesseract.js reported-screenshot test

The real Tesseract.js 6.0.1 fallback completed OCR and wrote its report without overwriting the original tracked baseline. Exact match **failed 8/9**: damage was read as `87313`, expected `87373`. No required fields were missing, demonstrating that required-field completeness alone can accept a wrong numeric value.

### Fresh Tesseract.js four-image sequence

The actual fallback completed all **4/4** jobs in one process, with times around 28.4–37.0 seconds, but exact expected-field match was **0/4** and required fields were complete in only **1/4**. The detailed report records the field mismatches. This does not validate accuracy and does not rule out the historical intermittent timeout; repeated runs and injected-stall tests remain for later phases.

### Native CLI comparison

This container has `/usr/bin/tesseract` version 5.5.0. A direct PSM 3 run on the reported screenshot recognized damage as `87373`, matching expected. The full bot native reported-screenshot pipeline did not complete within the tool's 120-second execution window and produced no report; this result is inconclusive, not a pass.

The user's Windows transcript still shows `tesseract.exe` is not available through PowerShell PATH. Native engine comparison on Windows remains open.

### Workbook baseline

Workbook hash remains:

`12ad80209ef77451b3586b52359a06b5361a68bc9926fc81a9da3d6c4b586397`

Static workbook XML shows `Totals!G12 = SUM(G3:G11,G14:G54)` with cached value `2312.5598233298197`, and `Totals!H12 = 0.54*G12/100` with cached value `12.487823045981026` (displayed as `$12.49`). Existing 50-player randomized scoring and archive tests passed in the full suite.

## Important issues not fixed by Phase 0

- The Tesseract.js fallback still misreads the reported screenshot's damage and fails all four fixture screenshots on exact-field comparison.
- The historical pass-16 sequential stall is not conclusively explained. Current baseline run completed four jobs, but only one fresh four-image run was performed.
- The cross-platform `npm run test:tesseractjs` acceptance command has not yet been implemented.
- A verified local-only/no-network test is still required.
- Native Tesseract CLI is absent from the user's Windows PATH; the full native pipeline was inconclusive in this container.
- The two Windows-skipped process-group cancellation tests still need equivalent native Windows coverage and a rerun on Windows Node.js 24.
- No actual Discord login, permission, attachment, rate-limit or restart/recovery smoke test was performed.
- The optional OCR diagnostics and verified-correction feedback system remains a future implementation phase.

## Release recommendation

Phase 0 baseline reconciliation is complete. The interactive-panel test harness is fixed, the report runner can preserve independent results, a fresh fallback baseline has been captured, and a clean ZIP assembly without `node_modules` is ready. This is not an OCR accuracy fix or a production-ready fallback release. Proceed to the sequential lifecycle phase and then field-accuracy work, using the reports in `testdata/phase0-baseline/` as the new baseline.
