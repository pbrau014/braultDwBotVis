'use strict';

// Portable image preprocessing adapter. Sharp is intentionally not required:
// ImageMagick's CLI is used to decode, resize, normalize, sharpen and crop images.
// This avoids native Node ABI / platform-specific sharp binary install failures.
const { spawn, spawnSync } = require('node:child_process');

function assertDimensions(width, height, options = {}) {
    const w = Number(width);
    const h = Number(height);
    const maxDimension = Math.max(2048, Number(options.maxDimension) || 12000);
    const maxPixels = Math.max(1_000_000, Number(options.maxPixels) || 40_000_000);
    if (!Number.isSafeInteger(w) || !Number.isSafeInteger(h) || w < 1 || h < 1) {
        throw new Error('The uploaded file does not contain a valid image size. Please upload a PNG, JPG, or WEBP screenshot.');
    }
    if (w > maxDimension || h > maxDimension || w * h > maxPixels) {
        throw new Error(`Image dimensions are too large (${w}×${h}). Maximum dimension is ${maxDimension}px and maximum area is ${maxPixels.toLocaleString()} pixels.`);
    }
    return { width: w, height: h, pixels: w * h };
}

function findPosixTimeout() {
    if (process.platform === 'win32') return null;
    const result = spawnSync('timeout', ['--version'], { stdio: 'ignore' });
    return !result.error && result.status === 0 ? 'timeout' : null;
}
const posixTimeout = findPosixTimeout();

function findImageMagick() {
    const candidates = [process.env.IMAGEMAGICK_BIN, 'magick', 'convert'].filter(Boolean);
    for (const candidate of candidates) {
        const check = spawnSync(candidate, ['-version'], { stdio: 'ignore' });
        if (!check.error && check.status === 0) return candidate;
    }
    return null;
}

const imageMagick = findImageMagick();

function runImageMagick(args, inputBuffer, testOptions = null) {
    const selectedImageMagick = testOptions?.command || imageMagick;
    if (!selectedImageMagick) {
        return Promise.reject(new Error(
            'Image preprocessing needs ImageMagick (magick/convert). Install ImageMagick or set IMAGEMAGICK_BIN.',
        ));
    }

    return new Promise((resolve, reject) => {
        const timeoutMs = Math.max(testOptions ? 100 : 1000, Number(testOptions?.timeoutMs ?? process.env.IMAGEMAGICK_TIMEOUT_MS) || 15000);
        const maxOutputBytes = Math.max(1_000_000, Number(process.env.MAX_IMAGEMAGICK_OUTPUT_BYTES) || 100_000_000);
        const usePosixTimeout = testOptions?.usePosixTimeout ?? !testOptions?.command;
        const command = usePosixTimeout && posixTimeout ? posixTimeout : selectedImageMagick;
        const baseArgs = [...(testOptions?.argsPrefix || []), ...args];
        const commandArgs = usePosixTimeout && posixTimeout
            ? ['--signal=TERM', '--kill-after=2s', `${Math.ceil(timeoutMs / 1000)}s`, selectedImageMagick, ...baseArgs]
            : baseArgs;
        const child = spawn(command, commandArgs, { stdio: ['pipe', 'pipe', 'pipe'], detached: process.platform !== 'win32' });
        const stdout = [];
        const stderr = [];
        let outputBytes = 0;
        let stderrBytes = 0;
        let settled = false;
        let failure = null;
        let timer;
        let terminationTimer;
        const cleanupListenersAndTimers = () => {
            clearTimeout(timer);
            clearTimeout(terminationTimer);
        };
        const killTree = () => {
            // Wait for `close` below before resolving/rejecting, rather than treating
            // a kill signal as proof that ImageMagick has already exited.
            try {
                if (process.platform !== 'win32' && child.pid) process.kill(-child.pid, 'SIGKILL');
                else child.kill('SIGKILL');
            } catch {}
            try { child.stdin?.destroy(); } catch {}
        };
        const fail = (error) => {
            if (settled || failure) return;
            failure = error;
            clearTimeout(timer);
            killTree();
            terminationTimer = setTimeout(() => {
                if (settled) return;
                settled = true;
                cleanupListenersAndTimers();
                const unconfirmed = new Error(`${error.message} ImageMagick did not confirm process exit after termination.`);
                unconfirmed.code = 'SERIAL_TASK_UNSETTLED';
                unconfirmed.cause = error;
                reject(unconfirmed);
            }, 3000);
        };
        timer = setTimeout(() => fail(new Error(`ImageMagick exceeded its ${timeoutMs} ms processing timeout.`)), timeoutMs);
        child.stdout.on('data', (chunk) => {
            if (failure || settled) return;
            outputBytes += chunk.length;
            if (outputBytes > maxOutputBytes) {
                fail(new Error(`ImageMagick output exceeded the ${maxOutputBytes.toLocaleString()} byte safety limit.`));
                return;
            }
            stdout.push(chunk);
        });
        child.stderr.on('data', (chunk) => {
            if (failure || settled || stderrBytes >= 100_000) return;
            const kept = chunk.subarray(0, Math.max(0, 100_000 - stderrBytes));
            stderr.push(kept);
            stderrBytes += kept.length;
        });
        child.on('error', (error) => fail(new Error(`Could not start ImageMagick: ${error.message}`, { cause: error })));
        child.on('close', (code) => {
            if (settled) return;
            settled = true;
            cleanupListenersAndTimers();
            if (failure) {
                reject(failure);
                return;
            }
            if (code !== 0) {
                reject(new Error(`ImageMagick failed (${code}): ${Buffer.concat(stderr).toString('utf8').trim().slice(0, 500)}`));
                return;
            }
            resolve(Buffer.concat(stdout));
        });
        child.stdin.on('error', (error) => { if (error.code !== 'EPIPE') fail(error); });
        child.stdin.end(inputBuffer);
    });
}

async function metadata(inputBuffer) {
    const info = await runImageMagick(['-', '-format', '%w %h', 'info:'], inputBuffer);
    const match = info.toString('utf8').trim().match(/^(\d+)\s+(\d+)$/);
    if (!match) throw new Error(`Could not read image dimensions from ImageMagick output: ${info.toString('utf8').slice(0, 100)}`);
    return { width: Number(match[1]), height: Number(match[2]) };
}

async function prepare(inputBuffer, targetWidth) {
    return runImageMagick([
        '-', '-auto-orient', '-resize', `${Math.max(1, Math.round(targetWidth))}x`,
        '-colorspace', 'Gray', '-normalize', '-unsharp', '0x1+1+0.05', 'png:-',
    ], inputBuffer);
}

async function cropResize(inputBuffer, rect, outputWidth, options = {}) {
    const left = Math.max(0, Math.round(rect.left));
    const top = Math.max(0, Math.round(rect.top));
    const width = Math.max(1, Math.round(rect.width));
    const height = Math.max(1, Math.round(rect.height));
    const args = ['-', '-crop', `${width}x${height}+${left}+${top}`, '+repage'];
    if (options.grayscale) args.push('-colorspace', 'Gray');
    if (options.contrastStretch) args.push('-contrast-stretch', String(options.contrastStretch));
    if (options.brightnessContrast) args.push('-brightness-contrast', String(options.brightnessContrast));
    if (options.sharpen) args.push('-unsharp', String(options.sharpen));
    args.push('-resize', `${Math.max(1, Math.round(outputWidth))}x`, 'png:-');
    return runImageMagick(args, inputBuffer);
}

module.exports = { metadata, prepare, cropResize, imageMagick, assertDimensions, __test: { runImageMagick } };
