'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

function sha256File(filePath) {
    return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function createOcrReportMetadata(root) {
    const packageInfo = require(path.join(root, 'package.json'));
    const { version: tesseractJsVersion } = require(path.join(root, 'node_modules', 'tesseract.js', 'package.json'));
    const { version: tesseractCoreVersion } = require(path.join(root, 'node_modules', 'tesseract.js-core', 'package.json'));
    const modelPath = path.join(root, 'eng.traineddata');
    const sourceFiles = [];
    const walk = relativeDir => {
        const absoluteDir = path.join(root, relativeDir);
        for (const entry of fs.readdirSync(absoluteDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
            const relative = path.posix.join(relativeDir.replaceAll(path.sep, '/'), entry.name);
            if (entry.isDirectory()) walk(relative);
            else if (entry.isFile() && !relative.endsWith('.bak')) sourceFiles.push(relative);
        }
    };
    for (const dir of ['src', 'scripts', 'tests']) if (fs.existsSync(path.join(root, dir))) walk(dir);
    sourceFiles.push('package.json', 'package-lock.json');
    const uniqueFiles = [...new Set(sourceFiles)].sort();
    const sourceHash = crypto.createHash('sha256');
    for (const relative of uniqueFiles) {
        sourceHash.update(relative).update('\0').update(fs.readFileSync(path.join(root, relative))).update('\0');
    }
    const { resolveLocalTesseractAssets } = require(path.join(root, 'src', 'ocr-worker'));
    const assets = resolveLocalTesseractAssets('eng');
    const assetPaths = [
        { role: 'language-model', path: modelPath },
        { role: 'worker-script', path: assets.workerPath },
        ...['tesseract-core.wasm.js', 'tesseract-core-simd.wasm.js', 'tesseract-core-lstm.wasm.js', 'tesseract-core-simd-lstm.wasm.js']
            .map(name => ({ role: 'wasm-core', path: path.join(assets.corePath, name) })),
    ];
    return {
        package: { name: packageInfo.name, version: packageInfo.version, engines: packageInfo.engines },
        sourceBuild: { sha256: sourceHash.digest('hex'), files: uniqueFiles.length },
        runtime: { node: process.version, platform: process.platform, arch: process.arch },
        engineVersions: { tesseractJs: tesseractJsVersion, tesseractJsCore: tesseractCoreVersion },
        languageModel: fs.existsSync(modelPath) ? { language: 'eng', source: path.relative(root, modelPath), sizeBytes: fs.statSync(modelPath).size, sha256: sha256File(modelPath) } : { language: 'eng', source: path.relative(root, modelPath), exists: false },
        localAssets: assetPaths.map(asset => ({ role: asset.role, path: path.relative(root, asset.path), exists: fs.existsSync(asset.path), ...(fs.existsSync(asset.path) ? { sizeBytes: fs.statSync(asset.path).size, sha256: sha256File(asset.path) } : {}) })),
    };
}

module.exports = { createOcrReportMetadata };
