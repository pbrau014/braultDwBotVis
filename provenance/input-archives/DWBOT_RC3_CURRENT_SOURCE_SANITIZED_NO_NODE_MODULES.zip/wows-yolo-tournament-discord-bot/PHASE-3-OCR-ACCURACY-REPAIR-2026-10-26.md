# Phase 3 OCR Accuracy Repair — 2026-10-26

## Change made

Tightened the localized-XP-versus-row-geometry comparison in `src/reward-geometry.js` and wired that shared rule into `src/bot.js`.

Previously, any XP value with three or more digits was treated as matching a longer geometry anchor when it was a prefix of that anchor. That made a truncated read such as `143` look acceptable against `143907`, so the independent width/PSM crop sweep could be skipped. The same pattern can hide other truncations, such as `405` against `4056`.

The updated rule accepts an exact value match, or the one documented exception: a five-digit XP read that equals the first five digits of a six-digit row token. Shorter prefixes now disagree with the anchor and can trigger the existing bounded crop sweep. The sweep still requires the current multi-width, multi-PSM quorum; the patch does not inject ground-truth answers, trim digits to match annotations, or weaken exact-match acceptance.

## Regression coverage

Added unit coverage for:

- `143` versus `143907`: mismatch, so recovery must not be suppressed.
- `14390` versus `143907`: accepted under the specific five-of-six XP exception.
- `405` versus `4056`: mismatch.
- Exact matching values and other reward-field prefixes.

No expected values or fixture annotations were changed. Existing historical test logs and acceptance reports were preserved.

## Checks run in this environment

- `node --test` selected reward-geometry, number-parser, localized-number-parser, damage-consensus, battle-record, 16-image corpus integrity, and workflow-contract tests: **77 passed, 0 failed**.
- `node --test tests/ocr-watchdog.test.js tests/windows-process-cancel.test.js tests/damage-consensus.test.js`: **18 passed, 0 failed**.
- JavaScript syntax check: **50 files checked, 0 failures**.

## Validation limitation and release decision

The execution environment is Linux with Node.js `v22.16.0`, below the project requirement `>=24.17.0`. `npm ci` could not complete because requests to the npm registry failed with `EAI_AGAIN`; the full Tesseract.js dependencies therefore were not installed, and I could not rerun the real OCR acceptance pipeline on the patched source here.

**This is a targeted code repair, not an OCR acceptance pass. Production remains NO-GO** until the patched source is installed and tested on Windows Node.js 24, the full 13-stage acceptance suite passes, all annotated fixtures match exactly, and the separate native-Windows-Tesseract and authorized Discord smoke-test gates are complete.

## Next validation commands (Windows, Node.js >=24.17.0)

```powershell
npm ci
npm test
npm run test:ocr-watchdog
npm run test:tesseractjs
```

Review the newly generated acceptance report and crop/PSM diagnostics for Hoffmann, Schlieffen, and the expanded 16-image corpus. Do not treat historical passing logs from a different source fingerprint or runtime as verification of this patch.
