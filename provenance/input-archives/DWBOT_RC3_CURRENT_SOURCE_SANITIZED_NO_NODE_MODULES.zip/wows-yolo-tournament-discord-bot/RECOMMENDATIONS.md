# Recommendations after Path 2 — build 2.5.0

## Preferred next steps, in order

1. **Validate on Node.js 24 LTS with the real locked dependencies.** Run `npm ci`, `npm ls --depth=0`, `npm test`, and both native OCR regression commands. The current 74/74 result used test-only dependency shims under Node.js 22.16.0 and must not be treated as clean-install proof.
2. **Run the real Discord smoke test in the existing public channel.** Verify authentication, intents, required permissions, attachments, public snapshots, command authorization, rate limits and restart recovery. Do not create private channels or use ephemeral replies.
3. **Exercise concurrent screenshots.** The Path 2 queue now covers download plus OCR, limits the accepted backlog, and stops safely if a timed-out task cannot be terminated or cleanup itself stalls. Test real target-host CPU/memory and throughput with several users at once.
4. **Test Tesseract.js fallback only after a clean install.** Force `OCR_ENGINE=tesseractjs`; use the real model/worker/core assets locally and verify all screenshot fields against expected values.
5. **Keep database backup practices explicit.** Run one bot process per database. For a physical single-file SQLite copy, stop the bot cleanly, allow the WAL checkpoint, then copy the database; keep JSON mirror and full archive snapshots as independent recovery routes.
6. **Expand the manually annotated OCR corpus.** The existing four fixtures are regression checks, not a complete estimate of field-level accuracy. Add images across resolutions/UI scaling and maintain explicit expected values, including ambiguous cases.

## Implemented in build 2.5.0

- Bounded OCR queue starts before attachment download, preventing an unbounded pile of in-memory images.
- OCR worker and ImageMagick process cancellation with child-close confirmation, bounded timeout cleanup, and a fail-closed fallback if a timed-out job or cleanup does not settle.
- Prior pending correction state is retained when submissions are rejected or attachment download/validation fails; typing-indicator failures are best-effort and queue-position notices are posted publicly for waiting screenshots.
- Independent 50-player event-score formula comparison under default and varied settings; JSON export/restore checks.
- SQLite WAL checkpoint at close and physical file-copy/reopen/integrity testing.
- Updated report provenance and build metadata.

## Release decision

Use the versioned 2.5.0 package as the acceptance-test candidate, not as an already live-validated production release. Current local evidence: **74/74 offline tests passed**, reported screenshot exact match, four native screenshots passed sequentially in one process, randomized 50-player formula checks passed, and physical SQLite copy/recovery passed. A clean install with real dependencies and the actual Discord integration remain unverified.
