> **DWBOT acceptance invariant:** All nine fields are required in this exact order: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `freeXp`, `damage`, `xp`. XP is mandatory and always ninth/final. Missing, invalid, uncertain, conflicting, or incorrect values block acceptance.
>
> **Latest validation update — 2026-10-28:** Handoff ZIP integrity and SHA-256 pass. In a fresh extraction, 171 dependency-independent tests pass and JavaScript syntax checks pass. Clean `npm ci` did not complete because the available environment is Node.js 22.16.0 while the project requires Node.js >=24.17.0; the full test suite had 2 bootstrap failures caused by unavailable `dotenv` and `tesseract.js`. OCR acceptance was not run. Release remains NO-GO; see `evidence/validation-2026-10-28-next-gate/VALIDATION-REPORT.md`.

---

> **DWBOT acceptance invariant:** All nine fields are required, in this exact order: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `freeXp`, `damage`, `xp`. XP is always the ninth/final field. Missing, invalid, uncertain, conflicting, or incorrect values block acceptance.

# World of Warships OCR + YOLO Tournament Discord Bot

This project unifies the screenshot OCR bot and the YOLO Tourney scoring workbook into one Discord-operated application (reliability hardening build 2.5.0). It does not require a separate hosted web app or database service. The production default uses a local transactional SQLite database (built into Node.js) plus an atomic JSON mirror/migration source. Full recovery snapshots are still posted publicly as JSON attachments in the same configured Discord channel as commands and screenshots. No hosted backend is required.

## What it does

### Screenshot OCR and verification

- Users upload World of Warships Personal Score / post-battle screenshots in the configured input channel.
- Tesseract OCR extracts the battle result, player, map, mode, battle start time, credits, Free XP, damage, and XP.
- A required value that is missing, weak, or contradictory is requested one at a time. The bot validates the answer before advancing; users can type `cancel correction` to cancel.
- XP is mandatory for record acceptance. Ship/result description and ribbon fields remain optional; the Destroyed-ribbon count can prefill the tournament kills field only when OCR captured it.
- A verified battle report is posted with a structured, versioned JSON battle-record attachment. The record ID prevents accidental reuse.

### Tournament management and scoring

- Maintains a roster and four events: Damage, Kills, Race, and Grand Yolo, with seven game slots per player in each event.
- Accepts screenshot results through a guided one-value-at-a-time mapping flow. It asks for the player, event, game slot, ship class, tier, and only those scoring metrics still missing. It never treats the screenshot timestamp as race time.
- Supports manual result entry and controlled correction/clearing by an admin.
- Recalculates player/event scores and standings using the formulas and source defaults in the supplied Excel/HTML workbook. The Excel workbook's Grand Yolo Tier weight is **0.9** (`d4!F10`); a previous browser build incorrectly defaulted it to 1.0, creating a $12.56 result instead of the workbook's true **$12.49**. This is corrected in the current build. The Grand Yolo pool is stored but not used in that formula.
- Exposes player score detail, round leaderboard, completed-slot count, and missing-slot report in Discord.
- Prevents accidental occupied-slot overwrite unless the admin explicitly supplies `--replace` to manual `result` entry. Duplicate battle record IDs are tracked.

### Persistence and export

- The active state is committed transactionally to `data/tournament-state.sqlite` by default. `data/tournament-state.json` remains an atomic JSON mirror and first-run migration/fallback source. Player roster, event results, settings, OCR records, mapping queue, and unfinished OCR corrections survive a normal restart.
- After committed state changes, the bot posts a full JSON snapshot in the same `TARGET_CHANNEL_ID` channel as commands and screenshots. Intermediate one-value mapping prompts/answers are saved to local JSON but do not each create a separate attachment. Assume the configured public channel exposes screenshots and recoverable tournament data to every channel viewer; all bot output and snapshots stay in this same channel by design.
- `!yolo export` (admin-only) attaches the full archive, including the workbook backup, battle records, and pending workflows.
- `!yolo export-workbook` (admin-only) attaches a version-2 JSON backup compatible with the original HTML workbook's full-backup importer.
- `!yolo download-workbook` (alias `!yolo workbook`) attaches the original Excel `.xlsm` source workbook, included in `assets/YOLO-Tournament-Workbook.xlsm`.
- `!yolo import` restores either a workbook-compatible backup or a full bot archive from a JSON attachment. It replaces the current state, so export a backup before importing.

**Workbook H12 source-of-truth check:** `Totals!G12 = SUM(G3:G11,G14:G54)` (all 50 participant rows) and `Totals!H12 = 0.54*G12/100`. The source workbook contains G12 = 2312.5598233298197 and H12 = 12.487823045981026, formatted as dollars to two decimals and therefore displayed as **$12.49**. The bundled `testdata/workbook-h12-source-truth.json` records the source formula, cached value, formatting, and workbook hash. The browser HTML uses a new v6 local-storage key and removes v1-v5 caches rather than migrating potentially incorrect Grand Yolo defaults.

**Storage note:** The production default is a local SQLite database at `data/tournament-state.sqlite`, committed in a transaction with full synchronous durability. `data/tournament-state.json` remains as an atomic JSON mirror and a migration/fallback source, while Discord snapshots remain the portable off-machine recovery layer. SQLite uses Node.js's built-in `node:sqlite` API; no hosted database or added SQLite npm dependency is needed. Use one bot instance per live state/database file. For an offline single-file SQLite copy, stop the bot cleanly so the store can checkpoint the WAL, then copy `data/tournament-state.sqlite`; also keep the atomic JSON mirror and a full JSON archive. Never copy only the main SQLite file while the bot is actively writing, and never treat a same-channel attachment as the only backup.

## Local computer-vision assist and offline OCR-engine benchmark

The screenshot pipeline can use a local OpenCV geometry-proposal stage before OCR. It analyzes the original image using local `cv2` connected-component/morphology operations and proposes bounded crops for result, player identity, metadata, the reward band, and damage. The helper **does not perform OCR and never accepts values**. Candidate text continues through the existing Tesseract parser, field-specific consensus, syntax/range validation, and unresolved-field handling. Invalid proposals are discarded; missing Python/OpenCV or helper failure falls back to the existing pipeline. OpenCV proposals are diagnostic evidence, not calibrated confidence values.

Install Python 3 and OpenCV from already-approved local/offline packages if needed. Use `OCR_CV_ASSIST=0` to bypass the OpenCV stage; `OCR_CV_ASSIST=1` enables it when local Python/OpenCV are available. `OPENCV_PYTHON_BIN` can point to an explicit local Python executable. `OCR_CV_DEBUG=1` logs fail-open helper failures. No screenshot, crop, or text is sent to any external service.

Run geometry coverage on the approved additional-image corpus with `python scripts/benchmark_opencv_field_isolation.py` (use `py -3` or your local Python executable on Windows). This verifies fixture hashes and that all returned crop rectangles are bounded; it does **not** claim OCR accuracy or prove that a proposed crop contains the intended field. Its output is `testdata/ocr-acceptance/opencv-field-isolation-benchmark.json`.

A local PaddleOCR raw-recognition benchmark harness is provided, but it is **not** enabled in the live pipeline. It will run only with an already-installed local Paddle/PaddleOCR package and pre-staged local detection and recognition model directories. No packages or models are installed or downloaded by the harness; all socket connections are blocked before PaddleOCR is imported. For PowerShell, set paths to local/offline resources first:

```powershell
$env:PADDLEOCR_PYTHON_BIN = 'C:\Python313\python.exe'
$env:PADDLEOCR_DET_MODEL_DIR = 'D:\local-models\paddleocr\det'
$env:PADDLEOCR_REC_MODEL_DIR = 'D:\local-models\paddleocr\rec'
npm run benchmark:paddleocr:offline -- --output testdata/ocr-acceptance/paddleocr-raw-benchmark.json
```

The report records engine versions, fixture hashes, raw OCR text, per-image latency, and failures. It deliberately leaves exact-field and complete-record metrics null because raw full-screen recognition is not the integrated field-specific pipeline. Do not integrate PaddleOCR as a fallback until it can be run on the same approved fixtures and a comparable field-aware evaluation demonstrates a measurable benefit. In this environment, PaddleOCR and local model weights are not present, so that benchmark is expected to report **BLOCKED** unless those artifacts are staged locally. The cloud/vision fallback phase is omitted by design: this deployment is requested to remain completely local and offline.

After an OCR sequence report is available, compute exact-field accuracy, complete-record accuracy, critical false-acceptance rate, unresolved rate, and the documented false-rejection proxy with:

```powershell
npm run summarize:ocr -- testdata/ocr-acceptance/sequence-report.json testdata/ocr-acceptance/metrics.json
```

The metric tool reads the approved ground-truth manifest rather than trusting any expected values echoed inside the OCR report. Missing output rows count as incomplete. A critical false acceptance is a nonempty incorrect field value among resolved field values; unresolved fields are reported separately. The false-rejection measure is explicitly a proxy because sequence outputs alone cannot distinguish OCR misses from conservative ambiguity rejection.

## Install and configure

Requirements: **Node.js 24.17.0 or newer** (use the current Node.js 24 LTS release), ImageMagick (`magick` or `convert`) for decoding, resizing and cropping screenshots, and npm dependencies. Native Tesseract is recommended for the best tested screenshot accuracy; install the Tesseract CLI and its English model if using `OCR_ENGINE=native` or `auto` with native Tesseract available. If native Tesseract is unavailable, the Tesseract.js fallback uses the bundled local `eng.traineddata` model (`gzip: false`, configurable with `TESSERACT_LANG_PATH`) and the installed `tesseract.js`/core npm packages. The language model is not fetched from a CDN. The bot applies configurable file-size, pixel-count, dimension, ImageMagick, native OCR process, and whole-image time limits. Image attachment downloads are admitted through the same bounded OCR queue, so a burst cannot create unbounded concurrent downloads/buffers. Waiting screenshots receive a public queue-position acknowledgement in the configured channel. If an OCR or ImageMagick child process cannot be confirmed stopped, or timeout cleanup itself stalls, the queue fails closed rather than overlapping another task; an operator must restart the bot after investigating the worker. Set `OCR_ENGINE=tesseractjs` to force the JavaScript engine or `OCR_ENGINE=native` to require the native CLI.

1. Create a Discord application and bot in the Discord Developer Portal. Copy the new bot token.
2. Invite the bot to your server with **View Channel**, **Read Message History**, **Send Messages**, and **Attach Files** permissions in the one configured channel. The channel is the input, command, report, and snapshot archive channel.
3. Enable **Message Content Intent** for the bot. It is needed for this message-based command workflow.
4. Copy `.env.example` to `.env` and fill in the values:
   - `DISCORD_BOT_TOKEN`: the bot token.
   - `TARGET_CHANNEL_ID`: the single channel in which users upload screenshots, run `!yolo` commands, receive reports, and collect JSON recovery snapshots.
   - `TOURNAMENT_ADMIN_IDS`: optional comma-separated list of admin Discord user IDs. Server members with Manage Server permission are admins too.
   - `TOURNAMENT_STORAGE`: `sqlite` by default; use `json` only as an explicit fallback.
   - `TOURNAMENT_SQLITE_PATH`: local SQLite database path.
   - `TOURNAMENT_STATE_PATH`: JSON mirror and first-run migration source path.
   - `ENABLE_SLASH_COMMANDS`: leave `0` to guarantee the existing one-channel-only interaction model. Slash command registration is opt-in; before enabling, restrict `/yolo` through Discord application-command permissions to the configured public channel.
   - `MAX_IMAGE_MB`, `MAX_IMAGE_PIXELS`, `MAX_IMAGE_DIMENSION`: image resource limits (defaults: 10 MB, 40 million pixels, 12,000 px per dimension). `MAX_PENDING_OCR_JOBS` defaults to 8 accepted screenshot jobs and is hard-capped at 32.
   - `IMAGEMAGICK_TIMEOUT_MS`, `OCR_PROCESS_TIMEOUT_MS`, `OCR_IMAGE_TIMEOUT_MS`: child-process and whole-image timeouts (defaults: 15 seconds for ImageMagick, 20 seconds per native OCR process, and 90 seconds per image).
   - `TESSERACT_LANG_PATH`: optional directory containing `<OCR_LANGUAGE>.traineddata` for the local Tesseract.js fallback.
5. From this project folder run:

```bash
npm ci
npm test
npm run test:reported-screenshot
npm run test:four-images
npm start
```

The bot starts with an empty tournament roster. Add your actual participants or import an existing workbook backup. This intentionally avoids using the HTML workbook's generic sample players and sample scores as live tournament data.

Do not distribute `.env`. If a real token has appeared in any shared file or ZIP, revoke/regenerate it in the Developer Portal before using the bot.

## Admin command reference

Commands must be sent in `TARGET_CHANNEL_ID`. Admin-only commands are marked **Admin**.

| Command | Purpose |
|---|---|
| `!yolo help` | Show command list |
| `!yolo panel` | Open public totals/standings/roster buttons and event selector |
| `!yolo players` | Show player names and stable numeric IDs |
| `!yolo player <name or ID>` | Show a player's event totals and game-by-game entries |
| `!yolo add-player <name>` (**Admin**) | Add a blank player with 28 empty game slots |
| `!yolo rename-player <name or ID> | <new name>` (**Admin**) | Rename while preserving results |
| `!yolo remove-player <name or ID>` (**Admin**) | Remove the active roster entry; OCR archive records are retained |
| `!yolo result <player> | <event> | <game> | <DD\|CA\|BB> | <tier> | <metric>` (**Admin**) | Manually enter a result; Grand Yolo uses `... | <damage> | <kills> | <time>` after tier |
| `!yolo result <player> | <event> | <game> | <class> | <tier> | <metric> --replace` (**Admin**) | Replace an occupied slot deliberately |
| `!yolo settings` | Display scoring parameters |
| `!yolo setting <event> <field> <number>` (**Admin**) | Change pool, multiplier, tier power or Grand Yolo weight |
| `!yolo standings` | Overall standings by total doubloons |
| `!yolo standings damage` | Leaderboard for one event; also `kills`, `race`, or `grand` |
| `!yolo status` | Count completed slots for each player/event |
| `!yolo missing` | List all missing slots |
| `!yolo missing race | <player or ID>` | List missing Race slots for one player |
| `!yolo clear-slot <player> | <event> | <game>` (**Admin**) | Clear one result; an associated OCR record is released for remapping |
| `!yolo clear-event <event> | <player or ID>` (**Admin**) | Clear one player's entries in an event |
| `!yolo clear-event <event> | ALL` (**Admin**) | Clear that event for all players |
| `!yolo clear-results CONFIRM` (**Admin**) | Clear all scores but retain roster and settings; records can be mapped again |
| `!yolo records` | List archived OCR records not yet mapped to a result slot |
| `!yolo map <record ID>` (**Admin**) | Restart mapping of a saved OCR record |
| `!yolo export` (**Admin**) | Attach the complete recovery archive JSON |
| `!yolo finalize` (**Admin**) | Attach one final export with completion counts; does not lock further edits |
| `!yolo export-workbook` (**Admin**) | Attach a workbook-compatible JSON backup |
| `!yolo download-workbook` / `!yolo workbook` | Download the source Excel `.xlsm` workbook |
| `!yolo import` + a `.json` attachment (**Admin**) | Replace current state with a valid workbook or full bot archive backup |

Events are `damage`, `kills`, `race`, and `grand`. Class weights are DD = 4, CA = 3, BB = 2. Tier must be a whole number from I to XI (entered as 1–11); damage and kills may be zero, while Race and Grand Yolo time must be positive.

## How a screenshot becomes a tournament result

1. A player uploads a screenshot.
2. The bot verifies all nine required report fields in order: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `freeXp`, `damage`, `xp`. Missing or uncertain values are requested one at a time; XP is always the ninth/final required field.
3. The bot posts the readable battle report and an individual JSON battle-record attachment, then stores the record in its archive.
4. The tournament mapper matches the in-game player name to the roster when possible. It asks only for required tournament fields that remain: roster player if unmatched, event, game number, class, tier, and event-specific metrics not captured reliably by OCR.
5. The bot validates the answers, saves the game slot, recalculates standings, and archives a full-state snapshot after committed changes. Intermediate one-field prompts are saved to local JSON but do not each create a separate Discord attachment. A duplicate record cannot be mapped twice without first releasing it by clearing its associated slot.

Damage uses damage; Kills uses the Destroyed ribbon count only when detected reliably, otherwise it asks for the kill count; Race requires race time; Grand Yolo requires damage, kills, and positive time.

## Validation and known limitations

Run `npm test` for the full offline unit and end-to-end command simulation, or `npm run test:system` for the simulated Discord integration suite alone. Tests cover a synthetic 3-player/84-slot tournament and a randomized roster of up to 50 players, compare event scores against the workbook formula reference, exercise documented command families, verify custom and zero settings, validate workbook/full-archive imports, test SQLite/JSON recovery and unfinished OCR recovery, and generate synthetic exports in `examples/synthetic-validation/`. Screenshot OCR quality remains image-dependent; manual confirmation remains part of the workflow for ambiguous fields. The external reference screenshot corpus in `testdata/reference-corpus.json` has pending manual ground-truth annotations, so it is not reported as a passing visual regression set.

The production bot is the same module used by the screenshot regression runners. The project includes diagnostic fixtures and runners:

```bash
npm run test:four-images
npm run test:reported-screenshot
npm run corpus:test
```

The corpus fetcher only uses the three URLs explicitly listed in the corpus manifest. It does not silently substitute other screenshots.

## Optional local PaddleOCR field-crop fallback (iteration 20)

Tesseract remains the primary OCR engine. The new PaddleOCR field-crop fallback is **disabled by default** and can only be enabled with `PADDLEOCR_FIELD_FALLBACK=1` plus explicit paths to a local Python interpreter and local detection/recognition models. It runs only for unresolved, ambiguous, or contradictory fields. Its output passes through the existing field parsers and consensus rules; raw model output cannot directly authorize a scoring record. The local Python worker blocks socket connections and does not download or invoke remote models/services.

Use `scripts/run-paddleocr-integrated-acceptance.ps1` from Windows PowerShell to run a paired Tesseract-only control and Tesseract-plus-Paddle field-crop candidate on the same Windows Node 24 host, in the same fixture order, with network blocking. The runner compares exact-field/complete-record accuracy, false acceptance, unresolved/human-review rates, whole-image latency, fallback latency, and per-crop latency. The 16-image corpus is development/tuning data, not an untouched holdout. See `docs/PADDLEOCR-FIELD-CROP-FALLBACK-ITERATION20.md` for configuration, benchmark outputs, safety rules, and remaining release gates. Keep the production feature flag off until accuracy and latency improve without increasing false acceptance and the Windows/native-Tesseract and Discord smoke-test gates pass.
