# Phase 3 targeted implementation report — RC3 candidate

**Date:** 2026-10-25  
**Source baseline:** preserved RC2 package `WoWS_YOLO_Tournament_Discord_Bot_Phase3_RC2.zip`  
**Decision:** targeted recommendations implemented in a separate working copy; local focused checks pass; **full OCR acceptance and target-Windows validation remain open**. RC2 itself is unchanged. RC3 is not production-approved.

## Summary

The work following the exact Windows RC2 failure analysis focuses on separating lifecycle evidence from OCR accuracy and improving field-specific evidence without hardcoding expected values or relaxing exact-match gates.

### Implemented changes

1. **Lifecycle and accuracy are separate acceptance gates.** The acceptance launcher uses an Asashio known-good fixture with `--lifecycle-only` to test the injected recognition stall, timeout, confirmed worker-thread termination, old child close, fresh recovery child close, and a well-formed output payload. A separate reported-screenshot recovery stage still requires every expected field to match. This prevents a damage OCR discrepancy from obscuring whether cleanup and restart took place, without calling the full recovery test green prematurely.
2. **Negative expected-value control now has a valid baseline.** The launcher first runs Asashio normally and requires its complete exact-field row and known expected damage. It then runs the same fixture with only the expected damage changed by one, and accepts the negative-control stage only if OCR actual values are identical and damage is the sole failed expected comparison. The full acceptance launcher now has 12 stages rather than the old 10.
3. **Reward-column geometry is generalized.** New `src/reward-geometry.js` uses independently segmented word boxes to locate Credits, XP, and Free XP fields, groups adjacent OCR tokens that plausibly belong to the same field, and builds three geometry variants per field. The caller rereads each geometry under PSM 8 and 13 and accepts a replacement only when a unique value has at least four agreeing reads across multiple crop widths and both PSMs. Unresolved contradictions remain missing and suppress broad tuple fallback from restoring a disputed value.
4. **Leading map OCR artifacts are normalized conservatively.** `cleanMapOcrPrefix` now removes leading `Victor`/`Victory`/`Defeat` banner fragments and leading 2–5-character all-caps artifacts (such as `ATRAT`) before the map name. It does not rewrite a known map name or force a particular expected value. Tests cover both observed prefix patterns.
5. **Regression coverage was expanded.** `tests/reward-geometry.test.js` covers anchor selection for fragmented Hoffmann/Libertad/Schlieffen reward tokens, crop bounds, and numeric-length bounds. `tests/battle-record.test.js` covers the observed map-prefix artifacts. The Tesseract.js acceptance unit/contract stage now includes both test files.
6. The existing damage consensus remains fail-closed: agreeing independent PSM 3/11 full-screen readings can override a conflicting focused crop; if independent sources disagree, damage remains unresolved. No damage value is hardcoded.

## Verification performed in this environment

- **Focused test set:** 60 passed, 0 failed, 0 skipped, exit code 0. This includes battle-record parsing, reward geometry, damage consensus, localized numeric parsing, process/worker watchdogs, queue semantics, Windows child-cancellation tests, preload path tests, and negative-control unit tests. Log: `PHASE-3-IMPLEMENTATION-FOCUSED-TESTS.log` (sidecar exit code `0`).
- **JavaScript syntax:** `node --check` across all `.js` files under `src/`, `scripts/`, and `tests/` passed, exit code 0. Log: `PHASE-3-IMPLEMENTATION-SYNTAX.log` (sidecar exit code `0`).
- Runtime available here: Linux x64, Node.js `v22.16.0`, npm `10.9.2`. The project requires Node.js `>=24.17.0`.
- **Not run / not passed:** `npm test` and `npm run test:tesseractjs` were not run in this working copy because required runtime dependencies (`dotenv`, `discord.js`, `tesseract.js`) are missing from the incomplete local `node_modules`, and this environment does not meet the declared Node version. No fresh OCR result on the modified source is claimed. These checks must be rerun on Windows Node.js `v24.22.1` or a supported Node.js `>=24.17.0` environment.

## Known issues intentionally left open

- The actual Windows RC2 acceptance report showed the reported screenshot's damage ambiguity (`873131` versus `87373`). The existing candidate-selection logic remains fail-closed. The new helper code has unit coverage, but its effect on real OCR has **not** been evaluated on the current source because the OCR dependencies are unavailable here.
- Hoffmann, Libertad, and Schlieffen's XP/Free XP issues are addressed by a geometry-based repair attempt, but this is not yet validated against those real screenshots. Credits can also trigger geometry rereads when the current value has an extra suffix digit.
- Map prefix cleanup now has regression tests, but the whole screenshot suite still needs to prove exact map extraction on Windows.
- Libertad's `O`/`0` player-name confusion remains unresolved. Do not force a canonical spelling from cross-screenshot ground truth; inspect high-confidence identity candidates before changing consensus.
- Reported-screenshot PSM 11 damage candidate formation still needs inspection in a live current-source JSON report. Existing consensus behavior is covered by unit tests, but that Windows-specific reading has not been reproduced here.
- First/middle/final recognition-pass stall injection has not been added yet. Keep it gated until the new source passes the isolated lifecycle check and the current-source OCR accuracy fixtures. The historical pass-16 root cause remains unknown.
- Windows native Tesseract (`tesseract.exe`) comparison and authorized live Discord smoke testing remain independent release gates.

## Required next run and GO/NO-GO boundary

On a fresh RC3 extraction, using Node.js `v24.22.1` or later, run and preserve each command's full output and exit code:

```powershell
node --version
npm --version
npm ci
npm ls --depth=0
npm test
npm run test:ocr-watchdog
npm run test:tesseractjs
```

Review `testdata/ocr-acceptance/<runId>/acceptance-report.json` and the per-stage logs. The new acceptance launcher has 12 stages. Require all 12 to pass, all five-image batches and both order tests to be exact, the negative-control baseline to pass before the one-field wrong-expected run, and the lifecycle-only Asashio test to prove timeout, termination, close, and successful fresh-child output. Keep the separate reported-screen recovery exact-match stage failed until damage and all other fields match.

**Production status: NO-GO.** This implementation is a test candidate; it must not be described as a successful Windows OCR acceptance run until the target-runtime commands above have actually passed on RC3.
