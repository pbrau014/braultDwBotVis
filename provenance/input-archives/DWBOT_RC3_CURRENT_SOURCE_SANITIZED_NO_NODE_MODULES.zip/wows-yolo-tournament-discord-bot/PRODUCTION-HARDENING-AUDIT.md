> **Historical report:** This document records the earlier Path A / 2.4.0 work. For the current Path 2 / 2.5.0 candidate, use `PATH2-2.5.0-AUDIT.md` and `VALIDATION-STATUS.md`; older recommendations and test counts below are retained only as project history.

# Path A production-hardening report — build 2.4.0

## Implemented

- Set the declared runtime to Node.js 24.17.0+ to align with the current official discord.js docs for the resolved package line. Node.js 24 is Active LTS as of this review. Sources: https://discord.js.org/docs and https://nodejs.org/en/about/previous-releases
- Configured the Tesseract.js fallback to use the bundled raw `eng.traineddata` file (`langPath` + `gzip: false`) instead of fetching language data from a CDN. Tesseract.js documents that Node.js supports a custom local `langPath`: https://github.com/naptha/tesseract.js/blob/master/docs/local-installation.md
- Added image file-type, pixel-count, dimension, subprocess-output, ImageMagick timeout, native Tesseract timeout, and whole-image timeout guards.
- On POSIX systems with GNU `timeout`, OCR/image subprocesses also get an independent process-level watchdog; other platforms use Node process timers.
- Added opt-in `OCR_DEBUG_TIMINGS=1` to identify slow OCR passes.
- Reduced archive noise: intermediate mapping prompt/answer state is saved to local JSON but no longer creates a new Discord snapshot for each step. Committed changes continue to snapshot to the same configured channel.
- Restricted `!yolo export` and `!yolo export-workbook` to tournament admins.
- Rejects non-image attachments before OCR.

## Earlier Path A validation (superseded by Release 2.4.0 validation in `VALIDATION-STATUS.md`)

- The earlier Path A test run had `npm test`: 54 passed, 0 failed. Release 2.4.0's current test run has 63 passed, 0 failed under the limited test environment described in `RELEASE-2.4.0-AUDIT.md`.
- Full synthetic tournament: 23 documented command families, 84 randomized game slots, all four event scoring functions, all 15 settings, player CRUD, clearing, missing slots, standings, JSON save/reload, import/export, and H12 source truth.
- `OCR_ENGINE=native npm run test:reported-screenshot`: all nine expected fields matched; required fields complete.
- `OCR_ENGINE=native npm run test:four-images`: 4/4 fixtures completed, all expected fields matched, and required fields complete. Per-image runtimes in the generated report were approximately 27–29 seconds.
- Excel source workbook hash and `Totals!H12` source-truth test pass; H12 displays `$12.49` for the bundled workbook's default data.
- Package archive excludes `.env`, `node_modules`, and live `data/` state.

## Still required before real deployment

- `npm ci` could not complete here because package fetching timed out. Run a clean `npm ci` followed by `npm test` on the target Node 24.17+ machine.
- The real Tesseract.js fallback could not be runtime-tested in this environment because the available cached dependency tree was incomplete. It now uses local model configuration, but validate `OCR_ENGINE=tesseractjs` after a clean install.
- No live Discord login or server permission test was possible. Verify the token, Message Content Intent, channel permissions, file attachments, and snapshot behavior in the existing public target channel, using synthetic data only.
- This release intentionally keeps everything public in the same configured channel. Everyone who can view that channel can read screenshots and recovery snapshots; do not create a private test/archive channel. Optional Discord-user-to-roster-player binding remains a future improvement.
- The 2.4.0 release candidate uses the expanded workbook formula `=SUM(G3:G11,G14:G54)` to aggregate all 50 participants. The bundled asset hash is recorded in `testdata/workbook-h12-source-truth.json`.

## Recommendations

1. Run a clean `npm ci` and smoke test on Node.js 24.17+.
2. In the existing public Discord channel, use synthetic data to upload one screenshot, complete a correction, map it to a slot, view totals, export a backup, download the workbook, and restart/restore the bot.
3. Decide whether to enforce a nine-player maximum or expand the workbook totals ranges.
4. Consider binding Discord user IDs to roster players for tournament integrity.
5. Keep separate offline copies of `data/tournament-state.sqlite` and `data/tournament-state.json`; Discord attachments are recovery snapshots, not the only backup.


## Release candidate 2.4.0 follow-up

- Production storage now defaults to Node.js built-in SQLite with transactional snapshot commits, schema versioning, JSON migration/mirror, and the existing same-channel recovery archive. JSON-only mode remains available with `TOURNAMENT_STORAGE=json`.
- Added `!yolo panel` public buttons and an event select menu. Slash `/yolo` registration is opt-in and disabled by default because Discord command availability is guild-wide unless permissions are constrained to the one configured channel. Do not enable it until that channel restriction is applied.
- Updated the workbook source-truth fixture to treat the expanded 50-player aggregate formula as authoritative while preserving the original cached default and `$12.49` display check.
- Acceptance still requires a fresh Node.js 24.17+ `npm ci`, real-image Tesseract.js fallback, a full four-image regression on this release candidate, and a live smoke test in the actual configured public channel. These cannot be represented as completed until those commands finish against real dependencies and the actual server.
