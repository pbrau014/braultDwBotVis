# Phase 2 Acceptance / Phase 2 RC1 PowerShell Quick Start — Windows Node.js 24

Use this guide against the **Phase 2 RC1 candidate** after it is packaged, not the older Phase 0, Phase 1 RC1, or Phase 1 RC2 ZIPs. Run from the extracted `wows-yolo-tournament-discord-bot` folder. The commands below are intended for Windows PowerShell; they do not use Unix environment-variable assignment.

## 1. Confirm runtime, dependencies and full tests

```powershell
node --version
npm --version
npm ci
npm ls --depth=0
npm test
if ($LASTEXITCODE -ne 0) { throw "npm test failed: $LASTEXITCODE" }
```

Use Node.js **v24.22.1 LTS or a later 24.x security patch** for this target-runtime gate; the package declares `>=24.17.0`. Node.js v24.22.1 was published as a security release on October 21, 2026 ([official release notes](https://nodejs.org/en/blog/release/v24.22.1)). The locked dependency versions are `discord.js@14.27.0`, `dotenv@16.6.1`, `tesseract.js@6.0.1`, and `tesseract.js-core@6.1.2`.

## 2. Run the complete local-only Tesseract.js acceptance command

```powershell
$env:OCR_IMAGE_TIMEOUT_MS = '95000'
$env:OCR_OPERATION_TIMEOUT_MS = '15000'
$env:OCR_WORKER_TERMINATION_TIMEOUT_MS = '3000'
$env:OCR_TERMINATION_TIMEOUT_MS = '3000'
$env:OCR_ACCEPTANCE_CHILD_TIMEOUT_MS = '480000'
$env:OCR_ACCEPTANCE_BATCH_REPEATS = '3'

npm run test:tesseractjs
$acceptanceExit = $LASTEXITCODE
"Tesseract.js acceptance exit code: $acceptanceExit"
if ($acceptanceExit -ne 0) { throw "Tesseract.js acceptance failed. Read the JSON report under testdata\ocr-acceptance. Do not ignore exact-field or timeout failures." }

$env:OCR_IMAGE_TIMEOUT_MS = $null
$env:OCR_OPERATION_TIMEOUT_MS = $null
$env:OCR_WORKER_TERMINATION_TIMEOUT_MS = $null
$env:OCR_TERMINATION_TIMEOUT_MS = $null
$env:OCR_ACCEPTANCE_CHILD_TIMEOUT_MS = $null
$env:OCR_ACCEPTANCE_BATCH_REPEATS = $null
```

The launcher sets `OCR_ENGINE=tesseractjs` internally; runs unit/contract and local-asset checks (including source/build, Tesseract.js/core versions, local English traineddata SHA-256 and worker/core asset hashes); runs a real OCR negative-control test that injects a wrong expected damage value and verifies a nonzero exit plus a recorded mismatch; performs a real Tesseract.js recognition, injects a stall into the next recognition, proves watchdog timeout plus underlying worker termination and supervised-child close, and then verifies a fresh child recovers the reported screenshot at 9/9 exact fields; runs the reported-screen case with the network guard; runs three five-image sequential batches; tests both Hoffmann/Asashio orders; asserts expected fields and required-field completeness; and exits nonzero for mismatches, missing fields, timeout/cleanup failures, or a detected network attempt. The launcher uses file-backed child output and explicit process-tree termination on timeout so descendants cannot keep captured pipes open indefinitely. Check `acceptance-report.json`, its SHA-256 sidecar, per-command logs, fixture JSON reports and exit code; do not rely on visual console output alone.

## 3. Inspect native Tesseract without changing machine-wide settings

The previous PowerShell transcript could not find `tesseract.exe`. Check common locations first:

```powershell
Get-Command tesseract -ErrorAction SilentlyContinue
$possible = @(
  'C:\Program Files\Tesseract-OCR\tesseract.exe',
  'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe'
)
$found = $possible | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($found) {
  & $found --version
  & $found --list-langs
  $env:TESSERACT_BIN = $found
} else {
  Write-Warning 'Native Tesseract CLI was not found in common locations. Install or locate it only if authorized, then set TESSERACT_BIN to the full path.'
}
```

The Tesseract project documentation says newer Windows installers are third-party rather than official project installers; it references UB Mannheim builds. Consult [Tesseract Windows downloads documentation](https://tesseract-ocr.github.io/tessdoc/Downloads.html) and the [UB Mannheim Tesseract download index](https://digi.bib.uni-mannheim.de/tesseract/). Use the default/new installation directory; the UB Mannheim page warns that its uninstaller removes the installation directory.

When the binary is available, run a native diagnostic separately from Tesseract.js:

```powershell
$env:OCR_ENGINE = 'native'
$env:OCR_SEQUENCE_REPORT_PATH = Join-Path $PWD 'testdata\phase1-evidence\native-windows-five-image.json'
node scripts/run-ocr-sequence.js
$nativeExit = $LASTEXITCODE
"Native OCR diagnostic exit code: $nativeExit"
$env:OCR_ENGINE = $null
$env:OCR_SEQUENCE_REPORT_PATH = $null
```

A native diagnostic is not a Tesseract.js acceptance pass. Preserve the native report separately and compare engine versions, model sources, PSM, preprocessing and field-level output. The Tesseract.js fallback remains required to pass its own exact-match gate even if native Tesseract does not.

## 4. Keep the evidence

Record the command, `node --version`, `npm --version`, exit code and report hashes. Keep the original Phase 0 reports and the new acceptance reports separate. If any command fails, preserve its generated reports before changing code.

## Target-runtime gate

The available implementation/test environment was Linux Node.js v22.16.0 with npm 10.9.2, below this package's declared Node.js minimum `>=24.17.0`. Local passes validate fallback behavior on this host only; they do not prove the latest source has passed on Windows Node.js 24. Phase 2 local acceptance can be marked complete, but target-Windows certification remains pending until this exact PowerShell validation is completed and reviewed. The prior clean-install attempt on this host did not complete observably, so it is not counted as a pass.
