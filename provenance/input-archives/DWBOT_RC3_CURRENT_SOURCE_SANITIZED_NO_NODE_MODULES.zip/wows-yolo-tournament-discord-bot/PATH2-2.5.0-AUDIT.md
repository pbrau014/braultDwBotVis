# Path 2 implementation audit — WoWS OCR + YOLO bot 2.5.0

Date: 2026-10-24

## Summary

This build extends the 2.4.0 candidate with reliability-first OCR queuing and additional formula/persistence acceptance tests. It is a release candidate only; clean install on Node.js 24+ and actual Discord deployment remain unverified.

## Changes implemented

### OCR admission, serialization and cancellation

- Screenshot attachment downloads now occur inside the bounded serial queue, not before queue admission. This limits concurrent download buffers when users submit bursts.
- The queue admits at most eight jobs by default and caps configuration at 32.
- A replacement screenshot only clears a user's pending OCR correction after an accepted queued job has successfully downloaded/validated its attachment and is about to start OCR. Queue-full and bad download/unsupported-size errors do not erase an existing pending correction.
- A whole-image deadline performs worker cleanup and then waits for the timed-out work promise to settle. If it does not settle within the 5-second grace window, the queue halts and refuses later work until the process is restarted; it does not allow a possibly still-running task to overlap another OCR task. Timeout cleanup itself is also bounded to the same grace window, and cleanup rejection or unconfirmed process exit also halts the queue.
- Native Tesseract and ImageMagick workers now abort an active child process and wait for the `close` event before treating cancellation as complete. If a process never confirms exit, it raises a fatal unsettled-task error and the OCR queue fails closed. Dedicated fake-child tests cover both cancellation paths.

### Independent scoring and recovery checks

- The randomized 50-player test fills 1,400 slots across four events and seven games per player. Each participant's event scores are compared against an independent formula reference, including varied multipliers, tier powers and Grand Yolo weights. JSON import/export and full-archive round-trips verify that scores/settings survive restores.
- The workbook-compatible JSON backup and full archive are round-tripped with scores/settings checked.
- SQLite clean shutdown checkpoints the WAL. An offline test copies the closed database file, opens the copy, compares all stored participants' data and checks SQLite integrity; JSON archive restore is separately tested.

### Test-report accuracy

- The reported-screenshot and four-image runners include build version and configured/selected OCR engine in report metadata.
- The current four-image report records a successful one-process sequential batch: all four fixtures completed, all expected values matched, and required fields were complete. The batch takes roughly two minutes in this environment, so interactive shell/tool time limits can interrupt it unless it is allowed to finish.

## Validation evidence

- `NODE_PATH=/mnt/data/path2_test_env/node_modules NODE_OPTIONS=--experimental-sqlite node --test`: **74 passed, 0 failed** under Node.js 22.16.0. The test environment uses lightweight test-only shims for Discord/dotenv and does not represent a clean install of production dependencies.
- Native reported screenshot: all nine expected fields matched, no required field missing. Ship text remains optional/ambiguous.
- Native fixture screenshots: 4/4 passed in one sequential process; all expected fields matched and no required fields were missing. Aggregate evidence: `testdata/four-screenshot-pipeline-results.json`.
- SQLite test covers basic transactional saves, JSON migration/mirror, queued snapshot correctness, full 50-player archive JSON recovery, physical closed-database copy/reopen/integrity, and mirror write failure.
- Randomized 50-player test covers all 28 slots per player and independent formula scoring for default and varied settings.
- `package.json`, `package-lock.json` are version 2.5.0 and declare Node.js `>=24.17.0`; the release directory/ZIP should exclude `.env`, `node_modules` and live `data/`.

## Open blockers

1. **Production runtime/dependencies:** Current machine is Node.js 22.16.0 and has no clean production install. The attempted install did not complete in the available execution window; its partial log shows an engine warning but does not establish a definitive network root cause. `npm ci` and `npm ls --depth=0` must pass under Node.js 24.17+ with the real package tree.
2. **Tesseract.js fallback:** Asset-path tests are not a replacement for running the installed JS OCR engine on real screenshots.
3. **Live Discord integration:** Login, intents, channel permissions, attachment delivery, queue behavior, snapshots, rate limits and recovery must be tested in the configured public channel.
4. **Real concurrency/throughput:** Native OCR takes roughly 25–28 seconds per fixture in this environment when each process initializes a worker. Benchmark multiple users and verify bounded backlog behavior under expected load.
5. **Wider OCR corpus:** Four fixtures do not fully characterize OCR accuracy. Manual ground-truth annotations should be expanded before making broad accuracy claims.

## Acceptance commands

Run on a clean target host with Node.js 24.17+:

```bash
npm ci
npm ls --depth=0
npm test
npm run test:reported-screenshot
npm run test:four-images
OCR_ENGINE=tesseractjs npm run test:reported-screenshot
```

Then exercise multiple simultaneous submissions and the complete workflow in the existing public Discord channel. All output and snapshots must remain in that channel; keep slash commands disabled until channel permissions have been explicitly restricted.

## Release recommendation

**Conditionally ready for target-machine acceptance, not fully production-verified.** The high-priority code-level Path 2 fixes and offline validations are implemented. Do not rely on the package for a live tournament until clean-install, real fallback OCR and actual Discord acceptance gates pass.


## Official runtime references reviewed

- Node.js lists v24 as LTS and v24.22.1 as the latest v24 patch at review time: https://nodejs.org/en/about/previous-releases and https://nodejs.org/en/download.
- discord.js 14.27 documentation requires Node.js 24.17.0 or newer: https://discord.js.org/docs.
- Node's built-in `node:sqlite` API is marked Stability 1.2 (Release Candidate) in the current v24 docs: https://nodejs.org/download/release/latest-v24.x/docs/api/sqlite.html. This remains an explicit operational trade-off for the local, no-hosted-database design.
