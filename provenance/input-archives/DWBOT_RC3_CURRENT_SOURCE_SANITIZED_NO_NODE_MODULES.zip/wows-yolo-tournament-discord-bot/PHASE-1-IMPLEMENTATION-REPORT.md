# Phase 1 Implementation and Acceptance Closeout

**Closeout result: implementation and locally feasible Phase 1 gates are complete; target Windows certification is blocked/not yet run. Production GO: NO.** This report distinguishes current reproduced evidence from older reports and from environment-dependent checks that could not be completed here. The authoritative plan is `plan1.txt`; the current evidence files are in `testdata/phase1-evidence/`.

## 1. Phase status matrix (0–8)

| Phase | Status | Evidence / remaining criterion |
|---|---|---|
| 0 — baseline and claim reconciliation | **COMPLETE** | Historical source, hashes, workbook calculations, original failure, and package comparison preserved. This is baseline closure, not OCR release approval. |
| 1 — real-dependency regression and cancellation | **COMPLETE locally; BLOCKED for target-Windows sign-off** | `npm test`: 102/102 pass, zero skips; discord.js panel payload test uses serialized `.toJSON()`; cross-platform child cancellation tests exercise actual children and confirm closure. Latest source has not been run on Windows Node 24. |
| 2 — Tesseract.js fallback and local-only acceptance | **COMPLETE locally; BLOCKED for target-Windows sign-off** | Latest launcher report: 9/9 commands passed, no blocked network attempts; real worker and language assets checked. Clean `npm ci` and acceptance on Windows Node 24 still required. |
| 3 — watchdog, termination and sequential recovery | **COMPLETE for current local acceptance; PARTIALLY COMPLETE overall** | Current integrated real-recognition → injected stall → watchdog → confirmed worker termination → child close → fresh-image recovery passed in three recorded successful reports and in the latest acceptance. Older transient attempts remain preserved; the root cause of the historical pass-16 issue is not conclusively established, and Windows lifecycle behavior remains unverified. |
| 4 — exact OCR match | **COMPLETE locally; BLOCKED for target-Windows sign-off** | Reported image 9/9; three five-image batches 5/5 each; two reverse orders 2/2; separate four-fixture run 4/4. |
| 5 — native Tesseract comparison | **BLOCKED on Windows; Linux diagnostics only** | Linux native Tesseract 5.5.0 diagnostics are preserved; native auto pipeline matched only 1/4 in one diagnostic. The recorded Windows transcript could not locate `tesseract.exe`; no Windows native pass is claimed. |
| 6 — optional privacy-safe correction/diagnostic data system | **OPEN** | Not implemented as a user-correction-linked, retention-controlled, deletion-capable system. Existing test evidence is not that product feature. |
| 7 — broader regression and workbook/scoring behavior | **COMPLETE locally; BLOCKED for target-Windows sign-off** | 102/102 suite passes including tournament, storage, workbook/score, interaction and OCR contract tests. Workbook SHA-256 remains `12ad80209ef77451b3586b52359a06b5361a68bc9926fc81a9da3d6c4b586397`. |
| 8 — versioned candidate and manifest | **COMPLETE as a release candidate; BLOCKED for production release** | RC2 is a separately versioned candidate built from the latest source. CRC integrity, manifest hashes, excluded-path scan, and the archive digest are recorded in the external `PHASE-1-PACKAGE-VERIFICATION-RC2.json` and the `.sha256` sidecar; that verification JSON stays outside the ZIP to avoid a self-referential archive hash. Windows Node 24, native Windows Tesseract, and authorized live Discord tests remain release gates. |

## 2. Baseline and runtime

- Package: `wows-yolo-tourney-discord-bot@2.5.0`.
- Declared engine: Node.js `>=24.17.0`; `.nvmrc` selects major 24.
- Latest local host: Linux x64, Node.js `v22.16.0`, npm `10.9.2`. This is below the declared engine range and is not a substitute for the required Windows run.
- Direct locked/resolved packages from `npm ls --depth=0`: `discord.js@14.27.0`, `dotenv@16.6.1`, `tesseract.js@6.0.1`, `tesseract.js-core@6.1.2`.
- Existing workbook was not modified; SHA-256 is unchanged at `12ad80209ef77451b3586b52359a06b5361a68bc9926fc81a9da3d6c4b586397`.
- Original Phase 0 ZIP, the prior Phase 1 RC1 ZIP, frozen reports, and historical failure evidence were left intact. RC2 is a separate versioned candidate.

## 3. Phase 1 code changes included in the candidate

- Fixed the discord.js full-system panel assertion to inspect the builder’s serialized payload (`.toJSON()`), retaining checks for custom IDs, values, labels, totals, event selection and channel isolation. Added/retained malformed and missing interaction coverage.
- Added cross-platform child-process cancellation regression coverage that tests real hanging Node children and waits for their `close` event instead of equating a kill request with confirmed termination.
- Added per-operation watchdogs for Tesseract.js `setParameters()` and `recognize()` in `src/ocr-watchdog.js`. On timeout, the implementation requests termination and confirms the underlying Node worker-thread exit before replacing the worker; uncertain termination fails closed.
- Added `src/ocr-process-supervisor.js` and `scripts/ocr-image-child.js`: each image is isolated in a supervised child; the parent enforces an independent deadline and waits for actual child closure before advancing.
- Added `scripts/block-network.js` to guard the acceptance worker path, `scripts/check-tesseractjs-assets.js` for local asset/package validation, `scripts/accept-tesseractjs.js` as the cross-platform multi-gate launcher, and the integrated injected-stall test/preload in `scripts/integrated-ocr-stall-recovery.js` and `scripts/inject-recognition-stall-preload.js`. The integrated test is part of the nine-command acceptance launcher.
- Refined focused OCR crops/field consensus and candidate selection to avoid icon-adjacent numeric false positives; preserved exact expected field assertions for the reported image and four named fixtures.
- Updated the PowerShell quick start with fixed Windows paths and exact Windows acceptance commands. Added current evidence, acceptance summaries, a checksum manifest and package verification for RC2.

## 4. Test and command results

All results below are actual runs, not estimates. Current acceptance-report reference: `testdata/phase1-evidence/acceptance-report.json`; report SHA-256: `0aaec6682daebb1a0dd092ea10027d5a8cc3f298d2e50e3529256677ab501895`. Full log: `testdata/phase1-evidence/acceptance-launcher-full-latest.log`.

| Command / gate | Runtime and result | Exit/result evidence |
|---|---|---|
| `npm test` | Linux x64 / Node 22.16.0; **102 passed, 0 failed, 0 skipped** | Exit 0; `npm-test-latest.log` and `.exit`. |
| `npm ls --depth=0` | Four expected top-level dependency packages resolved | Exit 0; `npm-ls-depth0-latest.log`. |
| `node --check` over `.js` files in `src`, `scripts`, and `tests` | Syntax checks passed | Exit 0; `node-check-latest.exit`. |
| `npm run test:tesseractjs` | **9/9 acceptance subcommands passed**; network guard enabled on all OCR acceptance paths; blocked network attempts: none detected | Acceptance report `passed: true`; per-command exit codes all 0; report digest above. |
| Integrated recognition → injected stall → cleanup → fresh-child recovery | 47.5 seconds in the latest acceptance | Watchdog timeout was logged; underlying worker termination confirmed; failed child close confirmed; recovery child close code 0; reported screenshot 9/9 exact; required fields missing `[]`; no network attempts. |
| Reported screenshot no-network case | 9/9 exact fields | Child close code 0; required fields complete. |
| Three sequential five-image no-network batches | Each **5/5 exact**, 5/5 complete required fields | Per-batch process exit 0; each image child closed code 0. |
| Hoffmann → Asashio and Asashio → Hoffmann | Each **2/2 exact**, all required fields complete | Both process exit codes 0. |
| Separate four-fixture Tesseract.js no-network batch | **4/4 exact** | Preserved earlier report `four-image-tesseractjs-no-network.json`. |
| Local Tesseract.js package/assets | Required local English model/core assets present; English traineddata SHA-256 `9d7c43fb206dc9f48475228b46bf35f888fa9e6259da2e67d5a75c77049f2dc7` | Asset check exit 0. |
| `npm ci --prefer-offline --no-audit --no-fund` | **INCOMPLETE / NOT PASS** on Node 22 host: `EBADENGINE` warning and no observable completion; dependency tree restored from pre-run backup | No reliable exit code captured. See `npm-ci-attempt-environment-note.md`. Do not infer an npm lockfile defect from this attempt. |
| Windows Node.js 24 commands | **NOT RUN on the latest source** in this environment | Target-machine gate is still open. |
| Windows native Tesseract | **BLOCKED / NOT RUN** | Recorded PowerShell did not find `tesseract.exe`. |
| Authorized live Discord smoke tests | **OPEN / NOT RUN** | Requires authorized bot credentials and target server/channel. |

### Integrated stall/recovery history

The current integrated scenario has three recorded passing end-to-end reports (at run IDs `2026-10-25T02-34-28-866Z-37901`, `2026-10-25T02-54-30-363Z-40010`, and `2026-10-25T02-57-32-366Z-40955`). In the newest acceptance invocation it passed as command 3/9. Each passing report confirms real recognition succeeded before the injected next-call hang, the 15-second watchdog expired, underlying worker-thread termination was confirmed, the supervised child closed, and a new child recovered the reported screenshot exactly. Earlier timeouts and an older harness report that used a stale script path and failed on `started is not defined` are retained as historical evidence; they are not deleted or reclassified as passes. This establishes repeatable current passes, but Windows target-runtime behavior still needs validation.

## 5. Exact OCR field acceptance

The latest reported-screenshot record matched all nine fields: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `xp`, `freeXp`, and `damage`.

| Fixture | Expected values matched exactly |
|---|---|
| Reported screenshot `Screenshot_2026-10-22_201950.png` | `Defeat`; `[AYNS]BabyEatingDingo`; `New Dawn`; `Random Battle`; `30.09.2026 14:46`; credits `540180`; XP `4906`; free XP `1536`; damage `87373`. |
| Hoffmann | `Victory`; `[-SEN-]WorldSpOwn`; `Mountain Range`; `Random Battle`; `27.03.2025 23:55`; credits `1237152`; XP `14390`; free XP `1645`; damage `303622`. |
| Asashio | `Defeat`; `[OVF]OldschoolGaming_YouTube`; `Northern Lights`; `Random Battle`; `14.07.2024 22:51`; credits `1650259`; XP `4059`; free XP `2110`; damage `171577`. |
| Libertad | `Victory`; `[OVF]OldschoolGaming_YouTube`; `Sea of Fortune`; `Random Battle`; `27.12.2024 23:30`; credits `511113`; XP `4509`; free XP `608`; damage `227678`. |
| Schlieffen | `Defeat`; `[ARGSY]Ensign_Cthulhu`; `Crash Zone Alpha`; `Brawl`; `28.08.2025 20:06`; credits `317943`; XP `2653`; free XP `325`; damage `131828`. |

Three fresh five-image sequences yielded 15/15 exact field records total; the order-reversal checks yielded 4/4 across two orders. These are fixture-set acceptance results, not a claim of universal OCR accuracy on arbitrary screenshots.

## 6. Sequential reliability, timeout and cleanup

- The launcher's current integrated sequence intentionally completes one real recognition pass, injects a hang on the following `recognize()`, requires `OCR_OPERATION_TIMEOUT`, requires confirmed underlying worker termination and confirmed failed-child closure, then launches a fresh child to OCR the reported real screenshot. The newest acceptance run passed this end-to-end scenario.
- All three five-image sequences and both two-image order checks were run in subprocesses with the network guard propagated using `NODE_OPTIONS`. Their child logs show close events and the sequence reports show exact matches and complete required fields.
- `testdata/phase1-evidence/acceptance-blocked-network-attempts.log` is empty; the acceptance JSON independently records `blockedAttemptsDetected: false`.
- Earlier transient attempts and the stale-harness `started is not defined` report remain preserved for audit; the latest acceptance launcher does not use that old script path.

## 7. Native vs. Tesseract.js comparison

The JavaScript fallback has current exact-match evidence described above. Native Tesseract 5.5.0 ran on the Linux host and its direct PSM 3 text outputs are retained. A separate `OCR_ENGINE=auto` native pipeline diagnostic matched only 1/4 fixture records exactly, so it is diagnostic evidence, not acceptance. The native engine comparison requested for Windows remains blocked until the Windows CLI path is located/installed and its results are saved separately. Do not substitute a Linux native diagnostic for that gate.

## 8. Correction-data / feedback system

No Phase 6 user-correction-linked diagnostic collection system is included in this closeout. Current `testdata/phase1-evidence` files are test artifacts, not a production feedback database. No automatic OCR learning from unverified output was introduced. A future Phase 6 implementation must keep collection local by default, make retention and deletion explicit, enforce quotas/rotation/deduplication, avoid credential collection, and mark ground truth only after user confirmation.

## 9. Remaining blockers and exact next actions

1. On Windows, install/use a supported Node.js 24.x version meeting `>=24.17.0` (Node.js v24.22.1 or later 24.x is recommended), extract RC2, then run the quick-start PowerShell commands and retain `npm ci`, `npm ls --depth=0`, `npm test`, and `npm run test:tesseractjs` outputs and exit codes.
2. Locate or install `tesseract.exe` in an authorized environment, set `TESSERACT_BIN`, and run the separate native five-image diagnostic; preserve it without confusing it with JS acceptance.
3. In an authorized Discord server, verify login, bot/channel permissions, image attachment delivery, failure/rate-limit handling, and restart/recovery. No live Discord actions were attempted in this environment.
4. Keep Phase 6 optional feedback/data work open until a separate privacy/retention design and acceptance test exist.

## 10. PowerShell quick start

Use the included `PHASE-1-QUICKSTART-POWERSHELL.md`. The primary acceptance commands are:

```powershell
node --version
npm --version
npm ci
npm ls --depth=0
npm test
$env:OCR_IMAGE_TIMEOUT_MS = '95000'
$env:OCR_OPERATION_TIMEOUT_MS = '15000'
$env:OCR_WORKER_TERMINATION_TIMEOUT_MS = '3000'
$env:OCR_TERMINATION_TIMEOUT_MS = '3000'
$env:OCR_ACCEPTANCE_CHILD_TIMEOUT_MS = '480000'
$env:OCR_ACCEPTANCE_BATCH_REPEATS = '3'
npm run test:tesseractjs
$acceptanceExit = $LASTEXITCODE
if ($acceptanceExit -ne 0) { throw "Acceptance failed: $acceptanceExit" }
```

## 11. Release decision

**Implementation/local acceptance: PASS. Production readiness: NO-GO.** The latest source passes 102/102 regression tests and 9/9 fallback acceptance subcommands with three repeated five-image exact-match batches, both reverse orders, no-network checks, and integrated stall/recovery. RC2 is a clean, checksum-verified release candidate, not a production release. The archive digest and verification JSON are supplied separately. The remaining target Windows Node.js 24 clean-install/test run, Windows native Tesseract comparison, and authorized live Discord smoke tests are explicit blockers.

## Phase 2 follow-up note — 2026-10-25

Phase 2 extends the acceptance launcher and report metadata without rewriting the Phase 1 historical record. The current regression suite is now 103/103 on Linux Node.js 22.16.0; the full Phase 2 local acceptance run passed 10/10 commands, and the current metadata-enabled source acceptance run passed 8/8 commands with one five-image batch. The newer role-labelled asset report distinguishes `eng.traineddata` SHA-256 `5dc5d8d640a212c9d6184921ba103b186f50e0fed9ee716c53e6b312b400d747` from the WASM-core asset hashes; an earlier summary mistakenly referred to the last WASM hash as the model hash. This correction is based on the current asset inventory and does not modify the historical report outputs. Windows Node.js 24, clean install, Windows native Tesseract and live Discord gates remain open.
