# Phase 2 Implementation and Acceptance Report

**Status:** Phase 2 implementation and local acceptance complete. Target-Windows Node.js 24 certification, clean-install verification, native Windows Tesseract comparison, and authorized live Discord smoke tests remain pending. This is not production approval.

## 1. Baseline and reconciliation

- Authoritative roadmap: `plan1.txt`.
- Preserved Phase 2 starting point: Phase 1 RC2, SHA-256 `6b8a6368f5d931f353e9750e58d08c7ea69c4d16be73f7c6d6f28b6a55bc971d`.
- Working copy: `phase1_work/wows-yolo-tournament-discord-bot`.
- Package: `wows-yolo-tourney-discord-bot@2.5.0`; declared Node.js engine `>=24.17.0`.
- Actual local runtime: Linux x64, Node.js `v22.16.0`, npm `10.9.2`. This is below the package engine requirement; all results below are local evidence only, not Node 24/Windows certification.
- Direct dependencies resolved by `npm ls --depth=0`: `discord.js@14.27.0`, `dotenv@16.6.1`, `tesseract.js@6.0.1`, `tesseract.js-core@6.1.2`.
- A byte-preserved roadmap snapshot from before Phase 2 edits is available as `plan1_phase1_rc2_baseline_2026-10-25.txt`.

## 2. Changes implemented

| File | Change | Why |
|---|---|---|
| `scripts/accept-tesseractjs.js` | Added an end-to-end negative expected-value gate; records source build fingerprint, package/lockfile hash, runtime and engine versions; writes child output to files and explicitly kills the process group/tree after timeout | Proves the real sequence command fails closed on wrong OCR output and prevents inherited descendant pipes from keeping the launcher blocked indefinitely |
| `scripts/run-ocr-sequence.js` | Added `OCR_ACCEPTANCE_TEST_MODE=1`-guarded expected-value override for negative testing; includes reproducibility metadata in sequence reports | Ensures the test hook is explicit and off by default; reports can be tied to the exact build/assets |
| `scripts/run-reported-screenshot-regression.js` | Adds report metadata | Captures runtime, engine, model and asset identities alongside field comparisons |
| `scripts/integrated-ocr-stall-recovery.js` | Streams child stdout/stderr while the child is running; records report metadata for success and failure | Makes an intermittent recovery hang diagnosable before the child exits and records lifecycle evidence reproducibly |
| `src/ocr-report-metadata.js` | New shared metadata collector for source fingerprint, package/runtime, Tesseract.js/core versions, `eng.traineddata`, worker script and WASM-core asset hashes | Distinguishes model hash from core asset hashes and enables report-to-build traceability |
| `tests/ocr-report-metadata.test.js` | New test for source hash, package/engine versions, model hash and local assets | Prevents metadata omissions and ensures hashes are valid/present |
| `PHASE-2-QUICKSTART-POWERSHELL.md` | New Phase 2 acceptance/PowerShell guidance | Documents new negative test, timeout handling, report metadata, and target-runtime caveat |
| `plan1.txt` | Reconciles Phase 0–8 status, records Phase 2 evidence and dependencies/limitations for future phases | Maintains a single roadmap authority without rewriting historical evidence |

## 3. Test results

### Full local regression

Command: `npm test`

- Result: **103 passed, 0 failed, 0 skipped**.
- Exit code: `0`.
- Runtime: Linux x64 / Node.js `v22.16.0`.
- Log: `PHASE-2-NPM-TEST-FINAL.log`.

Command: `npm ls --depth=0`

- Result: expected four direct dependencies resolved; exit code `0`.
- Log: `PHASE-2-NPM-LS-DEPTH0.log`.

### Tesseract.js acceptance

Full OCR behavior run `2026-10-25T03-20-04-937Z-47361`:

- **10/10 commands passed**, exit code `0`.
- Includes 34-test unit/contract group from that run, local asset check, real OCR negative-control test, integrated injected stall/recovery, reported screenshot, three five-image sequences, and both image orders.
- Three five-image sequences each matched **5/5 exactly**, with all required fields complete.
- Both reverse-order checks matched **2/2 exactly** with all required fields complete.
- Reported screenshot matched **9/9** expected fields.
- Network guard recorded **zero blocked network attempts**.
- Acceptance report SHA-256: `abde2ea8fd7331c92734ef716ee00a4a10c53f12dcc2e177ecbf62cfea5b07e0`.

Current-source metadata-enabled run `2026-10-25T03-31-59-739Z-51914`:

- **8/8 commands passed**, exit code `0`, using one five-image batch to revalidate the current metadata-enabled source.
- Five-image batch: **5/5 exact and complete**; both orderings: **2/2 exact and complete**; reported screenshot: **9/9**; integrated stall/recovery: pass; negative control: pass; local asset and 34-test contract checks: pass.
- Network guard recorded **zero blocked network attempts**.
- Acceptance report SHA-256: `ecb5861ad7a8a8f865209fb53196740b784d993e89508615e1a1250993a27656`.

Both reports and command logs are preserved under `testdata/phase2-evidence/`.

## 4. Negative-control proof

The launcher runs the real reported screenshot OCR sequence with test-only expected `damage=87313`; the expected ground truth is `87373`. OCR itself completed and returned the real damage value, the comparison failed, and the sequence exited with code `1`. The acceptance launcher counted this negative test as a pass only after verifying the JSON report had `comparison.damage.pass === false` and `allExpectedFieldsPass === false`. This confirms a deliberate expected-value mismatch fails closed in the actual sequence path, not merely in a unit-level comparator.

## 5. OCR accuracy results

All required values below matched exact ground truth in the three full five-image batches. The current-source metadata-enabled batch also matched 5/5.

| Fixture | Result | Player | Map | Mode | Battle time | Credits | XP | Free XP | Damage |
|---|---|---|---|---|---|---:|---:|---:|---:|
| Reported screenshot | Defeat | `[AYNS]BabyEatingDingo` | New Dawn | Random Battle | 30.09.2026 14:46 | 540180 | 4906 | 1536 | 87373 |
| Hoffmann | Victory | `[-SEN-]WorldSpOwn` | Mountain Range | Random Battle | 27.03.2025 23:55 | 1237152 | 14390 | 1645 | 303622 |
| Asashio | Defeat | `[OVF]OldschoolGaming_YouTube` | Northern Lights | Random Battle | 14.07.2024 22:51 | 1650259 | 4059 | 2110 | 171577 |
| Libertad | Victory | `[OVF]OldschoolGaming_YouTube` | Sea of Fortune | Random Battle | 27.12.2024 23:30 | 511113 | 4509 | 608 | 227678 |
| Schlieffen | Defeat | `[ARGSY]Ensign_Cthulhu` | Crash Zone Alpha | Brawl | 28.08.2025 20:06 | 317943 | 2653 | 325 | 131828 |

These results establish local fixture acceptance only; they do not establish accuracy for all possible screenshots.

## 6. Sequential reliability and recovery

- Three full five-image batches: **15/15 exact**, all required fields complete; each supervised child close was confirmed before the next image.
- Hoffmann → Asashio: **2/2 exact**.
- Asashio → Hoffmann: **2/2 exact**.
- Integrated test in both acceptance runs: genuine Tesseract.js recognition completed; next recognition was deliberately stalled; the 15-second watchdog fired; underlying worker termination was confirmed; stalled child closure was confirmed; fresh child then processed the real reported screenshot with 9/9 exact fields, no required fields missing, and no network attempts.
- The acceptance launcher was changed from pipe-captured output to file-backed output. This fixes the launcher-level failure mode where a child descendant can inherit captured pipe handles and prevent `spawnSync` from returning after the direct child times out. POSIX process groups and Windows process trees are explicitly targeted for termination after timeout.
- Historical transient failures/timeouts remain preserved. The original historical pass-16 incident root cause is not conclusively proven; do not claim its underlying cause has been identified.

## 7. Reproducibility and asset identity

Metadata-enabled reports record source fingerprint SHA-256 `e1a34cf51ce20bab6acd5d78e9395234bc82a40b884d39b1ba4b4bb668115144` (46 source/script/test/package files), `tesseract.js@6.0.1`, and `tesseract.js-core@6.1.2`.

- English model `eng.traineddata`: SHA-256 `5dc5d8d640a212c9d6184921ba103b186f50e0fed9ee716c53e6b312b400d747`.
- Worker and four WASM-core assets are each separately SHA-256 hashed in per-run metadata.
- Earlier Phase 1 text incorrectly described `9d7c43...` as the English model hash; it is actually the hash of `tesseract-core-simd-lstm.wasm.js` in that asset inventory. The new role-labelled metadata removes this ambiguity. Historical files remain unmodified.

## 8. Future phases reconciled

| Phase | Status after Phase 2 | Remaining condition |
|---|---|---|
| 0 — Baseline | COMPLETE | Baseline only; no release approval implied |
| 1 — Regression/panel/cancellation | COMPLETE locally; Windows gate pending | Run latest source on Windows Node 24 |
| 2 — Repeatable Tesseract.js acceptance | COMPLETE locally; Windows gate pending | Windows Node 24 clean install and acceptance |
| 3 — Lifecycle/recovery | Local injected stall/recovery passes; PARTIALLY COMPLETE overall | Historical pass-16 root cause remains unproven; Windows lifecycle run pending |
| 4 — OCR field accuracy | COMPLETE on local fixture set; Windows gate pending | Repeat exact-match suite on Windows Node 24 |
| 5 — Native Tesseract comparison | BLOCKED for Windows | Locate/install `tesseract.exe` with authorization and record native-vs-JS comparison |
| 6 — Privacy-safe correction/diagnostics | OPEN / optional | Define consent, data minimization, retention, deletion and holdout controls before implementation |
| 7 — Tournament/workbook regressions | COMPLETE locally (103/103); Windows gate pending | Re-run suite on Windows Node 24; preserve workbook SHA-256 `12ad80209ef77451b3586b52359a06b5361a68bc9926fc81a9da3d6c4b586397` |
| 8 — Packaging/release | Phase 2 RC1 packaged; production gate blocked | RC1 ZIP integrity, 294 manifest entries and forbidden-path scan pass; keep it as RC, not production release |

## 9. Remaining blockers and decision

1. **Node.js 24 / Windows:** host only has Node.js 22.16.0. Run `npm ci`, `npm ls --depth=0`, `npm test`, and `npm run test:tesseractjs` on Windows Node.js `>=24.17.0` (recommended existing target Node.js 24.22.1) and preserve logs and exit codes.
2. **Clean install:** `npm ci` did not complete observably in the prior Linux Node 22 attempt. This is unverified, not a pass and not proof of a dependency defect.
3. **Native Tesseract on Windows:** prior PowerShell transcript could not locate `tesseract.exe`; Windows comparison is not passed.
4. **Live Discord:** authorized real-environment login, channel permissions, attachment delivery, rate limits, and restart/recovery smoke tests remain unrun.
5. **Optional Phase 6:** remains open; no privacy-safe correction collection system is claimed.

**Decision:** Phase 2 is complete for implementation and local acceptance. The bot remains **NO-GO for production** until Windows Node.js 24 validation, clean install, native Windows comparison, and authorized live Discord smoke tests are completed or explicitly dispositioned.
