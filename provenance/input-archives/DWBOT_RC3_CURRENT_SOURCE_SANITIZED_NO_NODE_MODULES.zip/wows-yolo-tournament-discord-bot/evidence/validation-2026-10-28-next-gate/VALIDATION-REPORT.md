# DWBOT Next-Gate Validation Report — 2026-10-28

## Scope

Validated the checksum-verified reconciled Iteration 21 handoff in a fresh extraction. No Discord credentials, deployment, repository migration, or live Discord actions were used.

## Environment

- OS: Linux container
- Node.js: `v22.16.0`
- npm: `10.9.2`
- Declared project engine: Node.js `>=24.17.0`
- Handoff ZIP SHA-256: `a670627dc9d11d17633174673ae4cbf6047e73000a647930dce0466261380f6b`

## Results

| Check | Result | Evidence |
|---|---|---|
| Handoff SHA-256 | PASS | Matches expected checksum |
| ZIP integrity | PASS | `unzip -t` reported no errors |
| Clean `npm ci --no-audit --no-fund` | BLOCKED / NOT PASS | Did not complete within execution window; npm emitted EBADENGINE because Node 22.16.0 is below declared Node >=24.17.0 |
| Full `npm test` | BLOCKED by incomplete dependencies | 173 tests enumerated: 171 passed, 2 failed at test bootstrap due to missing `dotenv` and `tesseract.js` packages; no skips |
| Dependency-independent test subset | PASS | 171 passed, 0 failed, 0 skipped; the two dependency-dependent test files were excluded explicitly |
| JavaScript syntax sweep | PASS | `node --check` succeeded for all `.js` files in `src/`, `scripts/`, and `tests/` |
| OCR runtime / supervised screenshot acceptance | NOT RUN / NOT VERIFIED | Required Tesseract dependency could not be loaded; no OCR acceptance report produced |

## Contract invariant

The DWBOT record contract remains fixed: `result`, `player`, `map`, `mode`, `battleStart`, `credits`, `freeXp`, `damage`, `xp`. All nine fields are required; `xp` is ninth and final. Missing, invalid, uncertain, conflicting, or incorrect values must block acceptance.

## Decision

**Release remains NO-GO for production.** The 171-test dependency-independent pass and syntax sweep are useful partial evidence only. Do not interpret them as a clean-install, full-suite, OCR, Windows, holdout, or production acceptance pass.

## Required next steps

1. Run in a clean Windows x64 environment with Node.js >=24.17.0.
2. Run `npm ci`, verify `npm ls --depth=0`, and capture complete logs and exit codes.
3. Run `npm test`, `npm run test:tesseractjs`, and the full supervised acceptance pipeline.
4. Complete repeated screenshot runs, order reversals, additional screenshots, network-block evidence, and final machine-readable acceptance report.
5. Complete an independent never-tuned holdout with two independent labels for every required field and zero incorrectly accepted mandatory values.
6. Complete authorized Discord staging, persistence/recovery, workbook/scoring, backup/restore, and rollback tests.
7. Preserve original repository history; do not migrate or deploy before release gates pass.
