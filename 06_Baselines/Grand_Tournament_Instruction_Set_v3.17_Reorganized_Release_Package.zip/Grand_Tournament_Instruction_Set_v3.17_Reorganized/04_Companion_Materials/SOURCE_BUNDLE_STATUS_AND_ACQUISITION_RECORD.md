# Source Bundle Status and Acquisition Record
**Record version:** 1.0 — 29 October 2026  
**Audience:** Organizer / Technical Maintainer / Security Reviewer  
**Status:** OPEN — NO-GO for production deployment

## 1. Purpose

This record prevents an archived bot package from being mistaken for the current approved source. It records the exact source boundary used for v3.15 documentation and the evidence required before the current bot can be certified or distributed.

## 2. Current source status

| Item | Current finding | Disposition |
|---|---|---|
| `plan1.txt` / RC3 roadmap | The governing roadmap says targeted RC3 work exists in a separate work copy, focused tests passed, but full Windows Node 24 OCR acceptance remains unrun. | Roadmap is evidence of intent/status, not a substitute for source code or acceptance logs. |
| Exact RC3 source bundle | Not available in the accessible release materials used for this documentation pass. | **BLOCKING** — obtain the exact source archive and its producer/build identity. |
| Archived `discord-image-ocr-bot v1.0.0` | Historical test record: 32/32 unit tests passed under Linux Node v24.22.1; the reported-screenshot Damage field failed exact comparison (expected 87373, actual 87313; difference 60); the four-image pipeline timed out at 120 seconds. | Historical only. Do not use these results to certify RC3. |
| Archived HTML image reader | Prior audit observed a browser-side webhook/posting path. | Do not distribute the unsanitized archived reader. Live credential status is unverified. |
| Live webhook / credential rotation | No evidence of revocation or regeneration by the credential issuer was available. | **BLOCKING** — local source edits or a clean text scan do not prove rotation. |
| Final documentation package secret scan | A scan of generated v3.15 document artifacts is recorded separately in the final completion report. | Applies only to the listed documentation artifacts; not to absent RC3 source or any live service. |

## 3. Required acquisition procedure

1. Obtain the RC3 source bundle from its maintainer through an approved, access-controlled transfer. Do not rebuild or infer source contents from the older v1 archive.
2. Record exact filename, version/commit or build ID, source owner, receipt date/time and time zone, file size, and SHA-256 hash.
3. Inventory every file and nested archive. Preserve an untouched evidence copy before making any changes.
4. Search code, configuration, documentation, HTML, source maps, logs, and built assets for Discord webhook endpoints, bot tokens, API keys, secrets, and browser-side posting paths. Record tool versions, scan commands, results, and exceptions.
5. Remove client-side secret-bearing or unauthorized posting paths from the release build. Keep secrets server-side or in the approved secret manager; do not place them in HTML, JavaScript, user-facing settings, or distributable files.
6. Ask the authorized credential owner to revoke/regenerate any exposed live credential in the issuing service. Record confirmation and rotation time without copying the secret into the report.
7. Run the documented current Windows Node 24, local OCR/Tesseract comparison, exact-field screenshot, multi-image, and live Discord smoke suites on that exact source build. Attach full logs and fixture/build hashes.
8. Independent reviewer verifies source identity, scan output, credential response, acceptance evidence, and final archive manifest. Until then, keep the production release NO-GO.

## 4. Definition of done

This record is complete only when the exact RC3 source bundle and identity are attached, all nested files are scanned, no live secret remains in distributable artifacts, the credential owner provides rotation evidence where needed, exact-build Windows/OCR/Discord tests pass, and an independent reviewer signs the evidence record. None of those conditions is inferred from documentation edits alone.
