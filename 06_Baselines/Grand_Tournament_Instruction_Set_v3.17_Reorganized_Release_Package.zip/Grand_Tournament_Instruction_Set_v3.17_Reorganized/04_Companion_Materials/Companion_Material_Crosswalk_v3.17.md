# Companion Material Crosswalk — v3.17

The existing v1.1 companion materials are retained without silently rewriting their substantive rules. They remain drafts unless individually marked otherwise. Use the three reorganized publications as the role-based navigation layer, and consult the companion for its focused workflow.

| Companion | Primary audience / use | Main publication relationship | Status note |
|---|---|---|---|
| Participant Quick Start, Evidence and Results | Participants submitting evidence and understanding results | Participant Guide | Draft; event-specific submission route must come from approved event settings. |
| Pilot Event Ruleset | Pilot participants and staff | Participant Guide + Operations Manual | Draft; do not treat placeholders as approved event settings. |
| Recurring Tournament Ruleset | Recurring participants and staff | Participant Guide + Operations Manual | Draft; format-specific rules remain distinct from pilot rules. |
| Training Room Host and Referee Guide | Hosts and referees | Operations Manual | Draft; use only with approved room settings and authority. |
| Event Settings and Publication Approval Record | Organizer / approver | Operations Manual | Draft worksheet; no signatures or event-specific values are invented. |
| Scoring Workbook and Validation Guide | Scorekeepers and technical reviewers | Technical Reference | Draft; documented policies do not prove implementation or test success. |
| Discord Bot Maintainer Security and Release Guide | Bot maintainers | Operations Manual + Technical Reference | Draft; waived source/credential/runtime items remain out of scope, not passed. |
| Release Gate Closure Record | Release coordinator | Operations Manual + QA | Historical/working gate record; interpret with the explicit v3.17 scope waiver. |

## Scope and authority
The v3.15 master source is retained under `05_QA` for audit traceability. The three v3.17 publications redistribute the source by audience. This reorganization does not approve the event, certify scoring, or authorize live deployment.
