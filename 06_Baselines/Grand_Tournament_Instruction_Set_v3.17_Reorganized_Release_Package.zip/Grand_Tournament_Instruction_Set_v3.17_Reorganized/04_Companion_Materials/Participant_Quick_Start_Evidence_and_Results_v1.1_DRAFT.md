# Participant Quick Start — Match Evidence and Results
**Version:** v1.1-DRAFT  
**Audience:** Participants and team representatives  
**Status:** WORKING DRAFT — NOT APPROVED FOR EVENT PUBLICATION OR LIVE DEPLOYMENT

A concise participant-only workflow for confirming the correct event rules, submitting readable original battle evidence, checking scores and raising disputes. It avoids administrator commands and implementation details.

## 1. Before the event

1. Open the exact Pilot or Recurring ruleset named in the latest official notice. Check event time zone, arrival cutoff, map/mode, lineup rules, evidence route, settings version, and help contact.
2. Confirm that your in-game name matches the published roster or identity mapping. Ask the organizer to correct a mismatch before play.
3. Join the official communications route and keep the notice/support method available. Each team should have a primary and backup representative.

## 2. Before ready-up

1. Check the fixture ID, opponent, game number, map, mode, duration, team/ship limits and lineup visibility.
2. Wait until both team representatives confirm the room settings and legal lineup. Raise a mismatch before ready-up; do not assume the host’s check is enough.
3. Know the separate clocks for attendance, between-game wait, restart request and restart completion. Use only the event’s published limits.

## 3. Capture and submit evidence

1. After the battle, capture the original readable Personal Score/result screen required by the event. Include the visible player identity and the fields the event requires.
2. Do not crop out relevant values, paint over text, or edit the numeric result to make it agree with the calculator. If the image is unclear, retain it and request a clear original.
3. Submit through the event’s officially designated Discord channel/form or approved route. If the bot is unavailable, follow the published manual fallback. Do not send screenshots to an unverified private account.
4. If OCR text or a bot reply appears, compare it against the original screenshot. OCR is not the official score until accepted by the event’s recordkeeper.

## 4. What you should verify

| Field | What to check |
| --- | --- |
| Player / clan or alias | Matches your identity mapping and the correct game. |
| Battle Result | Victory/Defeat or draw as shown on the original result. |
| Map / mode | Matches the visible battle record and fixture. |
| Battle start time | Date/time is associated with the correct game. |
| Damage | Use the official post-battle Damage statistic specified by the rules; not potential damage. |
| Other OCR fields | Credits, Free XP or additional metadata only where the designated tool/event collects them; verify all against the source image. |

## 5. If something is wrong

1. Do not silently overwrite a disputed value or ask anyone to alter the screenshot. Preserve the original evidence and the bot/calculator response.
2. Send the match/game ID, disputed field, original screenshot, extracted value, and a short explanation to the official correction route.
3. If the issue affects a match result, pause bracket advancement until the referee rules. If it affects an individual score or award, pause that score/award publication while the discrepancy is checked.
4. Follow the published appeal deadline and include the opponent’s response where requested. A correction must retain the old value, new value, reviewer, reason and timestamp.

## 6. Definition of done

> **Submission complete when**: The original readable screenshot is linked to the correct participant and game, required values have been checked, the official recordkeeper has confirmed acceptance or requested a specific correction, and any dispute is recorded. A bot response alone is not proof that the record is accepted.

## Important policy notes

- Recurring bracket advancement uses the official match result and D21 tie-breaks, not an individual dblns value.
- Pilot Damage ranking determines only the individual awards expressly announced for that Pilot.
- The default participant-facing release suppresses H12; the historical $12.56 diagnostic is not cash value, official store price, prize valuation, or an award obligation.
