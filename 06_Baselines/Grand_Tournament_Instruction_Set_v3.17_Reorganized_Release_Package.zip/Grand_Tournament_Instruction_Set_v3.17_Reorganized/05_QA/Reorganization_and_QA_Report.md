# Reorganization and QA Report — v3.17

## Scope
The v3.15 policy-resolved source was reorganized into Participant Guide, Event Operations Manual, and Technical Reference. Companion materials and the complete v3.15 source baseline are retained.

## Source coverage
- Top-level source sections: 25
- Sections assigned across three publications: 25
- Missing top-level sections: 0
- Duplicate top-level section assignments: 0

## Internal Markdown anchors
- participant: 7 local anchor links; broken local anchors after rewriting: 0.
- operations: 8 local anchor links; broken local anchors after rewriting: 0.
- technical: 10 local anchor links; broken local anchors after rewriting: 0.

## Material changes
1. Replaced the single-manual reading path with three audience-based publications.
2. Added decision paths and status vocabulary to the operations manual and scoring discrepancy path to the technical reference.
3. Added role-specific front matter and document maps.
4. Retained the source baseline and companion documents for traceability.
5. Reworded cross-document anchors that no longer resolve locally into readable cross-reference text; review these references during editorial QA.

## Limitations and release status
- Working draft; not approved for event publication, score certification, or live bot deployment.
- No event settings, signatures, test results, or approvals were invented.
- User-waived technical/runtime/security items are not labeled as passed.
- Generated PDFs still require fresh visual inspection page by page.
- Source-section coverage is a structural check, not proof that every statement is substantively correct.


## Fresh visual inspection and final internal-link QA
- Freshly rendered and visually inspected all 67 pages across the three new PDFs; see `Fresh_Visual_Inspection_Report_v3.17.md`.
- DOCX internal links/bookmarks: Grand_Tournament_Participant_Guide_v3.17.docx: 7 links, 0 broken, Grand_Tournament_Event_Operations_Manual_v3.17.docx: 8 links, 0 broken, Grand_Tournament_Technical_Reference_v3.17.docx: 10 links, 0 broken.
- Markdown internal links: Grand_Tournament_Participant_Guide_v3.17.md: 7 links, 0 broken, Grand_Tournament_Event_Operations_Manual_v3.17.md: 8 links, 0 broken, Grand_Tournament_Technical_Reference_v3.17.md: 10 links, 0 broken.
- PDF internal navigation: Grand_Tournament_Participant_Guide_v3.17.pdf: 7 internal links, 0 broken, Grand_Tournament_Event_Operations_Manual_v3.17.pdf: 8 internal links, 0 broken, Grand_Tournament_Technical_Reference_v3.17.pdf: 10 internal links, 0 broken.
- Archive and file hashes are verified in the final package manifest.
