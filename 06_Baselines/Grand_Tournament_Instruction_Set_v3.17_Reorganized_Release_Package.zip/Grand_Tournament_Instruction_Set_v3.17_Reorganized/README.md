# Grand Tournament Instruction Set — Reorganized Publication v3.17

## Start here
This package reorganizes the v3.15 policy-resolved source into three role-based publications. The v3.15 master is retained in `05_QA` as the baseline for traceability.

## Main publications
- `01_Participant/Grand_Tournament_Participant_Guide_v3.17` — participant-facing rules and gameplay reference.
- `02_Operations/Grand_Tournament_Event_Operations_Manual_v3.17` — organizer, referee, host, Discord/bot operations, decision records, and checklists.
- `03_Technical_Reference/Grand_Tournament_Technical_Reference_v3.17` — scoring equations, implementation boundaries, evidence, reconciliation, and validation reference.

Each publication is supplied in Word, PDF, and Markdown. Companion materials are retained in `04_Companion_Materials`.

## Content and status controls
The reorganization preserves the substantive source sections and redistributes them by audience. It does not invent event settings, approvals, signatures, or technical test results. Items previously waived by user instruction remain labeled as waived/out of scope, not as passed. All publications remain working drafts and are not approved for event publication, score certification, or live bot deployment.

## Verification
See `05_QA/Reorganization_and_QA_Report.md` for source-section coverage, internal-link checks, file checks, and package integrity. The three new PDFs have undergone fresh visual inspection across all pages (67 pages total). See `05_QA/Fresh_Visual_Inspection_Report_v3.17.md` and its contact sheets.
